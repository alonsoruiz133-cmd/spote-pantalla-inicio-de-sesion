@echo off
setlocal
cd /d "%~dp0spote_app_stdlib"
echo SPOTE DEMOSTRACION - Datos ficticios
python app.py
if errorlevel 1 (
  echo.
  echo No se pudo iniciar. Comprueba que Python este instalado y disponible.
)
pause

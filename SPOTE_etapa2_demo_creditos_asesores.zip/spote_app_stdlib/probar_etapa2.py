"""Pruebas HTTP de integración para la Etapa 2, usando una copia temporal de SQLite.
Uso: python probar_etapa2.py --base /ruta/spote_normalizada.db
No altera la base suministrada ni usa Internet.
"""
import argparse
import contextlib
import http.client
import json
import os
import shutil
import sqlite3
import tempfile
import threading
import uuid
from datetime import date, datetime, timedelta, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlencode
import app

class Cliente:
    def __init__(self, port):
        self.port=port;self.cookie=''
    def req(self, metodo, ruta, datos=None, form=False):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=15)
        headers={}
        if self.cookie: headers['Cookie']=self.cookie
        if datos is not None:
            if form:
                body=urlencode(datos).encode();headers['Content-Type']='application/x-www-form-urlencoded'
            else:
                body=json.dumps(datos).encode();headers['Content-Type']='application/json'
        else:body=None
        c.request(metodo,ruta,body=body,headers=headers)
        r=c.getresponse();data=r.read();status=r.status
        cookies=r.getheaders()
        for name,value in cookies:
            if name.lower()=='set-cookie' and value.startswith('session_id='):
                self.cookie=value.split(';',1)[0]
        c.close()
        try:payload=json.loads(data)
        except (ValueError,UnicodeDecodeError):payload=data.decode('utf-8','replace')
        return status,payload
    def json(self,metodo,ruta,datos=None,esperado=200):
        status,payload=self.req(metodo,ruta,datos)
        assert status==esperado,(metodo,ruta,status,payload)
        return payload
    def login(self,correo,clave):
        estado,_=self.req('POST','/login',{'email':correo,'password':clave},form=True)
        assert estado==302,(correo,estado)
        assert self.cookie.startswith('session_id=')

def probar(base):
    if not Path(base).is_file():raise FileNotFoundError(base)
    n=0
    def assert_ok(test):
        nonlocal n
        test();n+=1
    with tempfile.TemporaryDirectory(prefix='spote_e2_') as carpeta:
        ruta=Path(carpeta)/'copia_spote.db'
        origen=sqlite3.connect(f'file:{Path(base).resolve()}?mode=ro',uri=True)
        destino=sqlite3.connect(ruta);origen.backup(destino);origen.close();destino.close()
        app.DB_PATH=str(ruta)
        app.init_db()
        admin_id=str(uuid.uuid4());admin_email='prueba.etapa2@example.com';clave='NoPublicarClaveDePrueba1234!'
        c=app.get_db()
        c.execute('''INSERT INTO vista_compat_usuarios(id,name,email,password_hash,created_at,first_name,last_name_paterno,role,active)
                     VALUES(?,?,?,?,?,?,?,'admin',1)''',
                  (admin_id,'Admin de prueba',admin_email,app.hash_password(clave),datetime.now(timezone.utc).isoformat(),'Admin','De Prueba'))
        c.commit();c.close()
        srv=ThreadingHTTPServer(('127.0.0.1',0),app.SpoteHandler)
        srv_thread=threading.Thread(target=srv.serve_forever,daemon=True);srv_thread.start()
        try:
            port=srv.server_address[1]
            admin=Cliente(port);admin.login(admin_email,clave)
            assert_ok(lambda:admin.json('GET','/api/admin/users'))
            estado,html=admin.req('GET','/admin/residencias');assert estado==200 and 'Verificación' in html;n+=1
            # Create teacher via exactly the same API as administration UI.
            p=admin.json('POST','/api/admin/users',{
                'role':'profesor','first_name':'María','last_name_p':'Pérez','last_name_m':'López',
                'career':'','semester':'','control_number':'','phone':'',
                'email':'maestra.etapa2@example.com','password':clave},201)
            pid=p['id'];assert p['role']=='profesor';n+=1
            profesor=Cliente(port);profesor.login('maestra.etapa2@example.com',clave)
            estado,html=profesor.req('GET','/profesor');assert estado==200 and 'asesorados' in html;n+=1
            profesor.json('GET','/api/tasks',esperado=403);n+=1
            profesor.json('GET','/api/admin/users',esperado=403);n+=1
            admin.json('GET','/api/profesor/residencias',esperado=403);n+=1
            # Period + verified plan, using fictitious school evidence.
            periodo=admin.json('POST','/api/admin/residencias/periodos',{
               'nombre':'Periodo de prueba 2027','fecha_inicio':'2027-01-10','fecha_fin':'2027-06-20'},201)['id_periodo']
            planes=admin.json('GET','/api/admin/residencias/contexto')['planes']
            plan=next((x for x in planes if x['carrera']=='Ingeniería en Sistemas Computacionales'),None)
            assert plan is not None;n+=1
            planid=plan['id_plan']
            admin.json('POST','/api/admin/residencias/planes',{
               'id_plan':planid,'creditos_totales':260,'fuente':'Plan curricular ficticio para pruebas 2027'})
            alumnos=[]
            for i in range(4):
                num=f'C8765432{i}'
                stu=admin.json('POST','/api/admin/users',{
                 'role':'estudiante','first_name':f'Alumno','last_name_p':f'Prueba','last_name_m':f'Uno',
                 'career':'Ingeniería en Sistemas Computacionales','semester':'10',
                 'control_number':num,'phone':f'81123456{i:02d}',
                 'email':num[1:]+'@saltillo.tecnm.mx','password':clave},201)
                alumnos.append(stu)
            n+=1
            # Ineligible until verified; then 208 credits => eligible.
            estado_pre=profesor.json('GET','/api/profesor/residencias')
            assert not any(x['id_alumno'] in [a['id'] for a in alumnos] for x in estado_pre['elegibles']);n+=1
            for stu in alumnos:
                ver=admin.json('POST','/api/admin/residencias/verificaciones',{
                    'id_alumno':stu['id'],'id_periodo':periodo,'creditos_aprobados':208,
                    'servicio_social':True,'actividades_complementarias':True,'sin_curso_especial':True,
                    'fuente':'Constancia ficticia verificada exclusivamente para pruebas'})
                assert ver['habilitado']
            n+=1
            candidatos=profesor.json('GET','/api/profesor/residencias')['elegibles']
            assert all(x['id_alumno'] in [a['id_alumno'] for a in candidatos] for x in [{'id_alumno':a['id']} for a in alumnos]);n+=1
            ids=[]
            for stu in alumnos[:3]:
                r=profesor.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':stu['id']},201);ids.append(r['id_asignacion'])
            n+=1
            profesor.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':alumnos[3]['id']},409);n+=1
            profesor.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':alumnos[0]['id']},409);n+=1
            # No student notification for preliminary selection.
            c=app.get_db()
            assert c.execute("SELECT COUNT(*) FROM notificaciones WHERE tipo='residencia_asesor_confirmado'").fetchone()[0]==0
            c.close();n+=1
            profesor.json('DELETE',f'/api/profesor/residencias/selecciones/{ids[0]}');n+=1
            profesor.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':alumnos[3]['id']},201);n+=1
            r=profesor.json('POST','/api/profesor/residencias/confirmar',{})
            assert r['confirmados']==3;n+=1
            profesor.json('POST','/api/profesor/residencias/confirmar',{},400);n+=1
            c=app.get_db()
            count=c.execute("SELECT COUNT(*) FROM notificaciones WHERE tipo='residencia_asesor_confirmado'").fetchone()[0]
            assert count==3, count
            check=c.execute('PRAGMA foreign_key_check').fetchall()
            assert not check,check
            c.close();n+=1
            estudiante=Cliente(port);estudiante.login(alumnos[1]['email'],clave)
            estado=estudiante.json('GET','/api/alumno/residencia')
            assert estado['asignacion'] and estado['asignacion']['estado']=='confirmada';n+=1
            estudiante.json('GET','/api/profesor/residencias',esperado=403);n+=1
            estudiante.json('GET','/api/notifications');n+=1
            # Ensure original task features still work via normalized DB.
            t=estudiante.json('POST','/api/tasks',{
               'title':'Prueba E2','description':'Texto de prueba','subject':'Otra materia de prueba',
               'professor':'María Pérez','category':'Individual','deadline':(date.today()+timedelta(days=10)).isoformat(),
               'type':'tarea','complexity':5,'status':'sin iniciar','collaborators':[]},201)
            assert t['title']=='Prueba E2';n+=1
            t=estudiante.json('PUT',f'/api/tasks/{t["id"]}',{'status':'terminado'})
            assert t['status']=='terminado';n+=1
            estudiante.json('GET','/api/progress');n+=1
            estudiante.json('DELETE',f'/api/tasks/{t["id"]}');n+=1
            # Original invariants from preexisting project:
            admin.json('POST','/api/admin/users',{
               'role':'profesor','first_name':'Pedro123','last_name_p':'Válido','email':'otro@example.com','password':'123456'},400);n+=1
            c=app.get_db()
            assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close();n+=1
        finally:
            srv.shutdown();srv.server_close();srv_thread.join(timeout=5)
    print(f'ETAPA 2: {n} verificaciones superadas (HTTP, perfiles, cupo, notificaciones y tareas).')

if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--base',required=True);a=pa.parse_args();probar(a.base)

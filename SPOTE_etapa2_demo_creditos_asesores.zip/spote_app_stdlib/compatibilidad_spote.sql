-- Adaptador NO destructivo: las tablas reales están en español y cumplen el esquema de Etapa 1.
-- Estas VISTAS de compatibilidad permiten reutilizar el código existente de SPOTE
-- sin almacenar tablas duplicadas vista_compat_usuarios/vista_compat_tareas/vista_compat_sesiones.
PRAGMA foreign_keys=ON;

CREATE VIEW IF NOT EXISTS vista_compat_usuarios AS
SELECT u.id_usuario AS id,
       trim(u.nombres || ' ' || coalesce(u.apellido_paterno,'') || ' ' || coalesce(u.apellido_materno,'')) AS name,
       u.correo AS email, u.contrasena_hash AS password_hash,
       c.nombre AS career, CAST(a.semestre AS TEXT) AS semester,
       u.fecha_creacion AS created_at, u.nombres AS first_name,
       u.apellido_paterno AS last_name_paterno, u.apellido_materno AS last_name_materno,
       a.numero_control AS control_number, u.telefono AS phone,
       u.foto_perfil AS avatar_data,
       CASE WHEN r.nombre='administrador' THEN 'admin' ELSE r.nombre END AS role,
       u.activo AS active
FROM usuarios u
JOIN roles r ON r.id_rol=u.id_rol
LEFT JOIN alumnos a ON a.id_alumno=u.id_usuario
LEFT JOIN planes_estudio p ON p.id_plan=a.id_plan
LEFT JOIN carreras c ON c.id_carrera=p.id_carrera;

CREATE TRIGGER IF NOT EXISTS compat_usuarios_insertar INSTEAD OF INSERT ON vista_compat_usuarios BEGIN
 INSERT OR IGNORE INTO carreras(nombre) SELECT NEW.career WHERE NEW.career IS NOT NULL AND trim(NEW.career)<>'';
 INSERT OR IGNORE INTO planes_estudio(id_carrera,version_plan,verificado)
   SELECT c.id_carrera, 'pendiente_de_verificacion',0 FROM carreras c WHERE c.nombre=NEW.career;
 INSERT INTO usuarios(id_usuario,id_rol,nombres,apellido_paterno,apellido_materno,correo,contrasena_hash,telefono,foto_perfil,activo,fecha_creacion)
   VALUES (NEW.id,
     (SELECT id_rol FROM roles WHERE nombre=CASE WHEN NEW.role='admin' THEN 'administrador' ELSE coalesce(NEW.role,'estudiante') END),
     coalesce(NEW.first_name,NEW.name),NEW.last_name_paterno,NEW.last_name_materno,
     NEW.email,NEW.password_hash,NULLIF(NEW.phone,''),NEW.avatar_data,coalesce(NEW.active,1),NEW.created_at);
 INSERT INTO alumnos(id_alumno,id_plan,numero_control,semestre)
   SELECT NEW.id, (SELECT p.id_plan FROM planes_estudio p JOIN carreras c ON p.id_carrera=c.id_carrera
       WHERE c.nombre=NEW.career ORDER BY p.id_plan DESC LIMIT 1), NEW.control_number,
       CAST(NULLIF(NEW.semester,'') AS INTEGER)
   WHERE coalesce(NEW.role,'estudiante')='estudiante';
 INSERT INTO profesores(id_profesor) SELECT NEW.id WHERE NEW.role='profesor';
END;

CREATE TRIGGER IF NOT EXISTS compat_usuarios_actualizar INSTEAD OF UPDATE ON vista_compat_usuarios BEGIN
 INSERT OR IGNORE INTO carreras(nombre) SELECT NEW.career WHERE NEW.career IS NOT NULL AND trim(NEW.career)<>'';
 INSERT OR IGNORE INTO planes_estudio(id_carrera,version_plan,verificado)
   SELECT c.id_carrera,'pendiente_de_verificacion',0 FROM carreras c WHERE c.nombre=NEW.career;
 UPDATE usuarios SET
   id_rol=(SELECT id_rol FROM roles WHERE nombre=CASE WHEN NEW.role='admin' THEN 'administrador' ELSE NEW.role END),
   nombres=coalesce(NEW.first_name,NEW.name), apellido_paterno=NEW.last_name_paterno,
   apellido_materno=NEW.last_name_materno, correo=NEW.email,
   contrasena_hash=NEW.password_hash, telefono=NULLIF(NEW.phone,''),foto_perfil=NEW.avatar_data,
   activo=NEW.active WHERE id_usuario=OLD.id;
 INSERT OR IGNORE INTO alumnos(id_alumno) SELECT OLD.id WHERE NEW.role='estudiante';
 UPDATE alumnos SET id_plan=(SELECT p.id_plan FROM planes_estudio p JOIN carreras c ON p.id_carrera=c.id_carrera
       WHERE c.nombre=NEW.career ORDER BY p.id_plan DESC LIMIT 1),
    numero_control=NEW.control_number, semestre=CAST(NULLIF(NEW.semester,'') AS INTEGER)
    WHERE id_alumno=OLD.id AND NEW.role='estudiante';
 INSERT OR IGNORE INTO profesores(id_profesor) SELECT OLD.id WHERE NEW.role='profesor';
END;
CREATE TRIGGER IF NOT EXISTS compat_usuarios_eliminar INSTEAD OF DELETE ON vista_compat_usuarios BEGIN
 DELETE FROM usuarios WHERE id_usuario=OLD.id;
END;

CREATE VIEW IF NOT EXISTS vista_compat_tareas AS
SELECT t.id_tarea AS id, t.id_usuario AS user_id, t.titulo AS title,
       t.descripcion AS description, coalesce(m.nombre,t.materia_personalizada) AS subject,
       t.nombre_profesor AS professor, t.categoria AS category, t.tipo AS type,
       t.complejidad AS complexity, t.fecha_entrega AS deadline, t.estado AS status,
       (SELECT coalesce(json_group_array(json_object('name', coalesce(
                 trim(u.nombres||' '||coalesce(u.apellido_paterno,'')||' '||coalesce(u.apellido_materno,'')),ct.nombre_no_vinculado),
                 'controlNumber', coalesce(a.numero_control,ct.numero_control_no_vinculado,''))),'[]')
        FROM (SELECT * FROM colaboradores_tarea WHERE id_tarea=t.id_tarea ORDER BY posicion) ct
        LEFT JOIN alumnos a ON a.id_alumno=ct.id_alumno
        LEFT JOIN usuarios u ON u.id_usuario=ct.id_alumno) AS collaborators,
       t.fecha_creacion AS created_at, t.fecha_terminacion AS completed_at
FROM tareas t LEFT JOIN materias m ON m.id_materia=t.id_materia;

CREATE TRIGGER IF NOT EXISTS compat_tareas_insertar INSTEAD OF INSERT ON vista_compat_tareas BEGIN
 INSERT INTO tareas(id_tarea,id_usuario,titulo,descripcion,id_materia,materia_personalizada,nombre_profesor,
                    categoria,tipo,complejidad,fecha_entrega,estado,fecha_creacion,fecha_terminacion)
 VALUES(NEW.id,NEW.user_id,NEW.title,NEW.description,
       (SELECT id_materia FROM materias WHERE nombre=NEW.subject),
       CASE WHEN EXISTS(SELECT 1 FROM materias WHERE nombre=NEW.subject) THEN NULL ELSE NEW.subject END,
       NEW.professor,NEW.category,NEW.type,NEW.complexity,NEW.deadline,NEW.status,NEW.created_at,NEW.completed_at);
 INSERT INTO colaboradores_tarea(id_tarea,posicion,id_alumno,nombre_no_vinculado,numero_control_no_vinculado)
 SELECT NEW.id, CAST(j.key AS INTEGER),
        (SELECT a.id_alumno FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber')),
        CASE WHEN EXISTS(SELECT 1 FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber'))
          THEN NULL ELSE coalesce(json_extract(j.value,'$.name'),'Sin nombre') END,
        CASE WHEN EXISTS(SELECT 1 FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber'))
          THEN NULL ELSE json_extract(j.value,'$.controlNumber') END
 FROM json_each(coalesce(NEW.collaborators,'[]')) j;
END;
CREATE TRIGGER IF NOT EXISTS compat_tareas_actualizar INSTEAD OF UPDATE ON vista_compat_tareas BEGIN
 UPDATE tareas SET titulo=NEW.title,descripcion=NEW.description,
   id_materia=(SELECT id_materia FROM materias WHERE nombre=NEW.subject),
   materia_personalizada=CASE WHEN EXISTS(SELECT 1 FROM materias WHERE nombre=NEW.subject) THEN NULL ELSE NEW.subject END,
   nombre_profesor=NEW.professor,categoria=NEW.category,tipo=NEW.type,
   complejidad=NEW.complexity,fecha_entrega=NEW.deadline,estado=NEW.status,
   fecha_terminacion=NEW.completed_at WHERE id_tarea=OLD.id;
 DELETE FROM colaboradores_tarea WHERE id_tarea=OLD.id;
 INSERT INTO colaboradores_tarea(id_tarea,posicion,id_alumno,nombre_no_vinculado,numero_control_no_vinculado)
 SELECT OLD.id, CAST(j.key AS INTEGER),
        (SELECT a.id_alumno FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber')),
        CASE WHEN EXISTS(SELECT 1 FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber'))
          THEN NULL ELSE coalesce(json_extract(j.value,'$.name'),'Sin nombre') END,
        CASE WHEN EXISTS(SELECT 1 FROM alumnos a WHERE a.numero_control=json_extract(j.value,'$.controlNumber'))
          THEN NULL ELSE json_extract(j.value,'$.controlNumber') END
 FROM json_each(coalesce(NEW.collaborators,'[]')) j;
END;
CREATE TRIGGER IF NOT EXISTS compat_tareas_eliminar INSTEAD OF DELETE ON vista_compat_tareas BEGIN
 DELETE FROM tareas WHERE id_tarea=OLD.id;
END;

CREATE VIEW IF NOT EXISTS vista_compat_sesiones AS SELECT id_sesion AS id,id_usuario AS user_id,fecha_creacion AS created_at FROM sesiones;
CREATE TRIGGER IF NOT EXISTS compat_sesiones_insertar INSTEAD OF INSERT ON vista_compat_sesiones BEGIN
 INSERT INTO sesiones(id_sesion,id_usuario,fecha_creacion) VALUES (NEW.id,NEW.user_id,NEW.created_at);
END;
CREATE TRIGGER IF NOT EXISTS compat_sesiones_eliminar INSTEAD OF DELETE ON vista_compat_sesiones BEGIN
 DELETE FROM sesiones WHERE id_sesion=OLD.id;
END;

CREATE VIEW IF NOT EXISTS vista_compat_recordatorios AS
SELECT id_recordatorio AS id,id_tarea AS task_id,id_usuario AS user_id,
       fecha_recordatorio AS remind_at,fecha_creacion AS created_at FROM recordatorios;
CREATE TRIGGER IF NOT EXISTS compat_recordatorio_insertar INSTEAD OF INSERT ON vista_compat_recordatorios BEGIN
 INSERT INTO recordatorios(id_recordatorio,id_tarea,id_usuario,fecha_recordatorio,fecha_creacion)
 VALUES (NEW.id,NEW.task_id,NEW.user_id,NEW.remind_at,NEW.created_at);
END;
CREATE TRIGGER IF NOT EXISTS compat_recordatorio_eliminar INSTEAD OF DELETE ON vista_compat_recordatorios BEGIN
 DELETE FROM recordatorios WHERE id_recordatorio=OLD.id;
END;

CREATE VIEW IF NOT EXISTS vista_compat_notificaciones AS
SELECT id_notificacion AS id,id_usuario AS user_id, tipo AS type,id_tarea AS task_id,
       titulo AS title,mensaje AS message,clave_deduplicacion AS dedupe_key,
       fecha_creacion AS created_at, fecha_lectura AS read_at FROM notificaciones;
CREATE TRIGGER IF NOT EXISTS compat_notificaciones_insertar INSTEAD OF INSERT ON vista_compat_notificaciones BEGIN
 INSERT OR IGNORE INTO notificaciones(id_notificacion,id_usuario,tipo,id_tarea,titulo,mensaje,clave_deduplicacion,fecha_creacion,fecha_lectura)
 VALUES(NEW.id,NEW.user_id,NEW.type,NEW.task_id,NEW.title,NEW.message,
        NEW.dedupe_key,NEW.created_at,NEW.read_at);
END;
CREATE TRIGGER IF NOT EXISTS compat_notificaciones_actualizar INSTEAD OF UPDATE ON vista_compat_notificaciones BEGIN
 UPDATE notificaciones SET fecha_lectura=NEW.read_at WHERE id_notificacion=OLD.id;
END;
CREATE TRIGGER IF NOT EXISTS compat_notificaciones_eliminar INSTEAD OF DELETE ON vista_compat_notificaciones BEGIN
 DELETE FROM notificaciones WHERE id_notificacion=OLD.id;
END;

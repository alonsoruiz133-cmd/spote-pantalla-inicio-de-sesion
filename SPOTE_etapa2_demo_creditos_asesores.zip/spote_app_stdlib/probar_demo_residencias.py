"""Comprueba los créditos ficticios, el cupo de 3 y los avisos en una COPIA TEMPORAL.

Uso: python probar_demo_residencias.py
Nunca modifica la base de datos entregada.
"""
import contextlib
import io
import os
from pathlib import Path
import sqlite3
import tempfile
import threading
from http.server import ThreadingHTTPServer
import app
from probar_etapa2 import Cliente
from crear_escenario_demo import ADMIN, PROFESOR, CLAVE


def probar():
    ruta_original = Path(__file__).with_name('spote_normalizada.db')
    if not ruta_original.is_file():
        raise FileNotFoundError('No se encontró la base de prueba spote_normalizada.db')
    ruta_anterior = app.DB_PATH
    pruebas=[]
    with tempfile.TemporaryDirectory(prefix='spote_creditos_prueba_') as temporal:
        destino=Path(temporal)/'copia_prueba.db'
        origen=sqlite3.connect(f'file:{ruta_original.resolve()}?mode=ro',uri=True)
        copia=sqlite3.connect(destino)
        origen.backup(copia)
        origen.close();copia.close()
        app.DB_PATH=str(destino)
        app.init_db()
        servidor=ThreadingHTTPServer(('127.0.0.1',0),app.SpoteHandler)
        servidor.log_message=lambda *args,**kwargs:None
        hilo=threading.Thread(target=servidor.serve_forever,daemon=True)
        hilo.start()
        try:
            admin=Cliente(servidor.server_address[1]);admin.login(ADMIN,CLAVE)
            prof=Cliente(servidor.server_address[1]);prof.login(PROFESOR,CLAVE)
            conn=app.get_db()
            try:
                recs={row['numero_control']:dict(row) for row in conn.execute('''
                    SELECT a.id_alumno,a.numero_control,
                    v.porcentaje_creditos,v.habilitado
                    FROM alumnos a LEFT JOIN vista_elegibilidad_residencia v
                    ON v.id_alumno=a.id_alumno''')}
                assert len(recs)==7
                assert recs['C90000002']['porcentaje_creditos']==80.0
                assert recs['C90000002']['habilitado']==1
                pruebas.append('208 de 260 créditos = 80%, aprobado')
                assert recs['C90000005']['porcentaje_creditos'] < 80.0
                assert recs['C90000005']['habilitado']==0
                pruebas.append('207 de 260 créditos = menos del 80%, bloqueado')
                assert recs['C90000006']['habilitado']==0
                pruebas.append('240 créditos sin servicio social, bloqueado')
                assert recs['C90000007']['habilitado'] is None
                pruebas.append('Alumno sin verificación, bloqueado')
            finally:
                conn.close()
            panel=prof.json('GET','/api/profesor/residencias')
            assert len(panel['elegibles'])==4 and not panel['asignaciones']
            pruebas.append('El profesor ve cuatro candidatos elegibles y ningún asesorado')
            id_aprobados={r['numero_control']:r['id_alumno'] for r in panel['elegibles']}
            for numero in ('C90000001','C90000002','C90000003'):
                prof.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':id_aprobados[numero]},esperado=201)
            pruebas.append('Se permite seleccionar hasta tres alumnos')
            ineligible=recs['C90000005']['id_alumno']
            prof.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':ineligible},esperado=403)
            pruebas.append('No permite seleccionar a un alumno con créditos insuficientes')
            prof.json('POST','/api/profesor/residencias/seleccionar',{'id_alumno':id_aprobados['C90000004']},esperado=409)
            pruebas.append('Cuarta selección bloqueada por cupo máximo')
            conn=app.get_db()
            assert conn.execute("SELECT COUNT(*) FROM notificaciones WHERE tipo LIKE 'residencia_asesor%'").fetchone()[0]==0
            conn.close()
            pruebas.append('Seleccionar NO genera notificaciones')
            result=prof.json('POST','/api/profesor/residencias/confirmar',{})
            assert result['confirmados']==3
            pruebas.append('Tres asignaciones confirmadas por el profesor')
            conn=app.get_db()
            avisos=conn.execute("SELECT id_usuario,tipo FROM notificaciones WHERE tipo LIKE 'residencia_asesor%'").fetchall()
            assert len(avisos)==3, [tuple(x) for x in avisos]
            assert len({x['id_usuario'] for x in avisos})==3
            assert all(x['tipo']=='residencia_asesor_confirmado' for x in avisos)
            pruebas.append('Una sola notificación por alumno confirmado (3 en total)')
            assert not conn.execute('PRAGMA foreign_key_check').fetchall()
            assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            conn.close()
            pruebas.append('Integridad referencial correcta después de las asignaciones')
            prof.json('POST','/api/profesor/residencias/confirmar',{},esperado=400)
            pruebas.append('Confirmación repetida rechazada sin notificaciones adicionales')
            alum=Cliente(servidor.server_address[1]);alum.login('90000002@saltillo.tecnm.mx',CLAVE)
            perfil=alum.json('GET','/api/alumno/residencia')
            assert perfil['habilitado'] and perfil['asignacion']['estado']=='confirmada'
            pruebas.append('Alumno consulta el asesor confirmado desde su cuenta')
            no_aprob=Cliente(servidor.server_address[1]);no_aprob.login('90000005@saltillo.tecnm.mx',CLAVE)
            perfil=no_aprob.json('GET','/api/alumno/residencia')
            assert not perfil['habilitado'] and perfil['asignacion'] is None
            pruebas.append('Alumno con 207 créditos ve su acceso no habilitado')
            alum.json('GET','/api/profesor/residencias',esperado=403)
            pruebas.append('Alumno no puede acceder a API de selección de profesor')
        finally:
            servidor.shutdown();servidor.server_close();hilo.join(timeout=5)
            app.DB_PATH=ruta_anterior
    print('PRUEBAS DE CRÉDITOS Y ASESORÍAS DE RESIDENCIAS — DEMOSTRACIÓN')
    for i,desc in enumerate(pruebas,1):
        print(f'{i:02d}. OK — {desc}')
    print(f'\nRESULTADO: {len(pruebas)}/{len(pruebas)} pruebas satisfactorias (en una copia temporal).')

if __name__ == '__main__':
    probar()

# SPOTE Etapa 2

Lee `../LEEME_ETAPA2.md` antes de iniciar. Este servidor requiere una base SQLite normalizada llamada `spote_normalizada.db` en esta carpeta.

- Si tienes `spote.db` anterior, ejecútale el migrador de `../migracion_3fn/` y conserva el original.
- Si deseas empezar desde cero, copia la base limpia `../migracion_3fn/spote_estructura_demo.db` a `spote_normalizada.db`, después ejecuta `python app.py --crear-admin`.
- Usa `python app.py` para arrancar.

La aplicación no crea usuarios automáticamente.

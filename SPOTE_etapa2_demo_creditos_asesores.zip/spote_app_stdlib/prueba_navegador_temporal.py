import os,sqlite3,threading,tempfile
from pathlib import Path
from http.server import ThreadingHTTPServer
import app
from playwright.sync_api import sync_playwright
from crear_escenario_demo import PROFESOR,CLAVE
ruta_original=app.DB_PATH
with tempfile.TemporaryDirectory(prefix='spote_browser_') as tmp:
    path=Path(tmp)/'demo.db'
    origin=sqlite3.connect(f'file:{Path(ruta_original).resolve()}?mode=ro',uri=True)
    dest=sqlite3.connect(path);origin.backup(dest);origin.close();dest.close()
    app.DB_PATH=str(path);app.init_db()
    server=ThreadingHTTPServer(('127.0.0.1',0),app.SpoteHandler)
    server.log_message=lambda *args,**kwargs: None
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
            pg=browser.new_page(viewport={'width':1400,'height':900})
            base='http://127.0.0.1:'+str(server.server_address[1])
            pg.goto(base+'/login',wait_until='domcontentloaded')
            pg.locator('#email').fill(PROFESOR)
            pg.locator('#password').fill(CLAVE)
            pg.locator('button[type=submit]').first.click()
            pg.wait_for_url('**/profesor',timeout=6000)
            pg.locator('#elegiblesNumero').wait_for(timeout=8000)
            pg.wait_for_function("document.getElementById('elegiblesNumero').textContent==='4'",timeout=6000)
            assert pg.locator('.residencia-alumno').count()==4
            pg.screenshot(path='/mnt/data/spote_demo_work/vista_profesor_demo.png',full_page=True)
            pg.locator('#candidatosLista button').first.click()
            pg.wait_for_function("document.getElementById('asesoradosActuales').textContent==='1/3'",timeout=6000)
            assert pg.locator('#candidatosLista button').count()==3
            print('NAVEGADOR: login Profesor OK, cuatro elegibles, selección de primer alumno OK; captura creada.')
            browser.close()
    finally:
        server.shutdown();server.server_close();th.join(timeout=5)
        app.DB_PATH=ruta_original

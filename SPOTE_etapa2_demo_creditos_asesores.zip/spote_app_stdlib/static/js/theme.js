/* SPOTE - apariencia compartida en login, dashboard y administración. */
(() => {
  const key = 'spote_theme_preference';
  const allowed = ['light', 'dark', 'system'];
  let preference = 'system';
  try {
    const saved = localStorage.getItem(key);
    if (allowed.includes(saved)) preference = saved;
  } catch (_) { /* Navegador sin almacenamiento disponible */ }
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  const apply = () => {
    const resolved = preference === 'system' ? (media.matches ? 'dark' : 'light') : preference;
    document.documentElement.dataset.theme = resolved;
    document.documentElement.dataset.themePreference = preference;
    document.querySelectorAll('[data-theme-choice]').forEach(btn => {
      const active = btn.dataset.themeChoice === preference;
      btn.classList.toggle('selected', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  };
  apply();
  if (media.addEventListener) media.addEventListener('change', apply);
  else if (media.addListener) media.addListener(apply);
  document.addEventListener('DOMContentLoaded', () => {
    apply();
    document.querySelectorAll('.theme-picker').forEach(picker => {
      const trigger = picker.querySelector('.theme-trigger');
      const menu = picker.querySelector('.theme-menu');
      trigger.addEventListener('click', () => {
        const open = menu.hidden;
        document.querySelectorAll('.theme-menu').forEach(m => m.hidden = true);
        menu.hidden = !open;
        trigger.setAttribute('aria-expanded', String(open));
      });
      menu.querySelectorAll('[data-theme-choice]').forEach(btn => {
        btn.addEventListener('click', () => {
          preference = btn.dataset.themeChoice;
          try { localStorage.setItem(key, preference); } catch (_) {}
          apply();
          menu.hidden = true;
          trigger.setAttribute('aria-expanded', 'false');
        });
      });
      document.addEventListener('click', e => {
        if (!picker.contains(e.target)) {
          menu.hidden = true;
          trigger.setAttribute('aria-expanded', 'false');
        }
      });
      document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
          menu.hidden = true;
          trigger.setAttribute('aria-expanded', 'false');
        }
      });
    });
  });
})();

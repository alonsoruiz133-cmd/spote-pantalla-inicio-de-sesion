'use strict';
const el=(id)=>document.getElementById(id);
function aviso(t,err=false){const x=el('academicoAviso');x.textContent=t;x.className=err?'flash flash-error':'flash flash-success';x.style.display='block';}
async function peticion(url,opts={}){
 const r=await fetch(url,{headers:{'Content-Type':'application/json'},credentials:'same-origin',...opts});
 if(r.status===401){location.href='/login';throw Error('Sesión finalizada');}
 const data=await r.json();if(!r.ok)throw Error(data.error||'Error del servidor');return data;
}
function opciones(id,list,valor,etiqueta){
 const x=el(id);x.replaceChildren();const inicio=document.createElement('option');inicio.value='';inicio.textContent='Seleccionar...';x.appendChild(inicio);
 for(const i of list){const o=document.createElement('option');o.value=String(valor(i));o.textContent=etiqueta(i);x.appendChild(o);}
}
async function recargar(){const r=await peticion('/api/admin/residencias/contexto');
 opciones('planId',r.planes,x=>x.id_plan,x=>`${x.carrera} (${x.version_plan}) · ${x.creditos_totales??'Sin créditos'} ${x.verificado?'✓':''}`);
 opciones('verAlumno',r.alumnos,x=>x.id,x=>`${x.name} · ${x.control_number||'sin control'} · ${x.career||''}`);
 opciones('verPeriodo',r.periodos.filter(x=>x.activo),x=>x.id_periodo,x=>x.nombre);
}
function conectar(form,url,datos,mensaje){el(form).addEventListener('submit',async(ev)=>{
 ev.preventDefault();try{const respuesta=await peticion(url,{method:'POST',body:JSON.stringify(datos())});
 aviso(mensaje+(Object.hasOwn(respuesta,'habilitado')?respuesta.habilitado?' Alumno habilitado.':' El alumno todavía no cumple todos los requisitos.':''));await recargar();
 }catch(e){aviso(e.message,true);}
});}
document.addEventListener('DOMContentLoaded',()=>{
 conectar('periodoForm','/api/admin/residencias/periodos',()=>({nombre:el('periodoNombre').value,fecha_inicio:el('periodoInicio').value,fecha_fin:el('periodoFin').value}),'Periodo creado.');
 conectar('planForm','/api/admin/residencias/planes',()=>({id_plan:el('planId').value,creditos_totales:el('planCreditos').value,fuente:el('planFuente').value}),'Plan verificado.');
 conectar('verificacionForm','/api/admin/residencias/verificaciones',()=>({id_alumno:el('verAlumno').value,id_periodo:el('verPeriodo').value,creditos_aprobados:el('verCreditos').value,
   servicio_social:el('verSocial').checked,actividades_complementarias:el('verComplementarias').checked,sin_curso_especial:el('verSinEspecial').checked,fuente:el('verFuente').value}),'Verificación registrada.');
 recargar().catch(e=>aviso(e.message,true));
});

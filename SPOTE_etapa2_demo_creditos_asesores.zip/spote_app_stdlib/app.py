"""
SPOTE - Sistema para Organización de Tareas y Exámenes
Versión SIN DEPENDENCIAS: usa únicamente la librería estándar de Python
(http.server, sqlite3, hashlib, json, etc.). No requiere "pip install" nada.

Cómo correrla:
    python3 app.py
Luego abre: http://localhost:5000

Las cuentas se migran de la base anterior o las crea un administrador autorizado.
"""

import base64
import binascii
import getpass
import hashlib
import http.cookies
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import sys
import threading
import traceback
import unicodedata
import uuid
from datetime import date, datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from materias import ALIAS_CARRERAS, MATERIAS_POR_CARRERA

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SPOTE_DB_PATH", os.path.join(BASE_DIR, "spote_normalizada.db"))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")
PORT = 5000

DB_LOCK = threading.Lock()


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def init_db():
    """Verifica estructura 3FN. No crea ni reemplaza bases heredadas."""
    if not os.path.isfile(DB_PATH):
        raise RuntimeError("No existe spote_normalizada.db. Ejecuta primero migrar_spote.py; consulta LEEME_ETAPA2.md")
    conn = get_db()
    existing = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not {"usuarios", "roles", "tareas", "profesores", "asignaciones_residencia"}.issubset(existing):
        conn.close()
        raise RuntimeError("La base indicada no contiene el esquema normalizado de Etapa 1. No se ha modificado.")
    ruta_compat = os.path.join(BASE_DIR, "compatibilidad_spote.sql")
    conn.executescript(open(ruta_compat, encoding="utf-8").read())
    conn.close()



# Etapa 2: deshabilitada la creación automática de cuentas con claves conocidas.
# Usa `python app.py --crear-admin` para registrar un administrador seguro.


def upsert_admin(conn, email, password, name):
    row = conn.execute("SELECT id FROM vista_compat_usuarios WHERE email = ?", (email,)).fetchone()
    if row:
        conn.execute("UPDATE vista_compat_usuarios SET role = 'admin', active = 1 WHERE id = ?", (row["id"],))
        conn.commit()
        return False
    conn.execute(
        "INSERT INTO vista_compat_usuarios (id, name, email, password_hash, created_at, first_name, role, active) "
        "VALUES (?, ?, ?, ?, ?, ?, 'admin', 1)",
        (
            str(uuid.uuid4()),
            name,
            email,
            hash_password(password),
            datetime.now(timezone.utc).isoformat(),
            name,
        ),
    )
    conn.commit()
    return True


def ensure_admin_from_env(conn):
    email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    password = os.environ.get("ADMIN_PASSWORD", "")
    if not email or not password:
        return
    if not ADMIN_EMAIL_RE.match(email) or len(password) < 8:
        print("ADMIN_EMAIL o ADMIN_PASSWORD no son válidos (la contraseña necesita al menos 8 caracteres).")
        return
    upsert_admin(conn, email, password, "Administrador")


def create_admin_cli():
    print("Crear (o promover) una cuenta de administrador")
    email = input("Correo del administrador: ").strip().lower()
    if not ADMIN_EMAIL_RE.match(email):
        print("Correo no válido.")
        return
    name = " ".join(input("Nombre (Enter para 'Administrador'): ").split()) or "Administrador"
    password = getpass.getpass("Contraseña (mínimo 8 caracteres): ")
    if len(password) < 8:
        print("La contraseña necesita al menos 8 caracteres.")
        return
    if password != getpass.getpass("Confirma la contraseña: "):
        print("Las contraseñas no coinciden.")
        return
    conn = get_db()
    created = upsert_admin(conn, email, password, name)
    conn.close()
    if created:
        print("Administrador creado. Ya puedes iniciar sesión con ese correo.")
    else:
        print("Esa cuenta ya existía: solo se le asignó el rol de administrador (su contraseña no cambió).")


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000)
    return f"{salt}${dk.hex()}"


def verify_password(password, stored):
    try:
        salt, hash_hex = stored.split("$", 1)
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000)
    return secrets.compare_digest(dk.hex(), hash_hex)


def create_session(user_id):
    session_id = secrets.token_hex(24)
    conn = get_db()
    conn.execute(
        "INSERT INTO vista_compat_sesiones (id, user_id, created_at) VALUES (?, ?, ?)",
        (session_id, user_id, datetime.now(timezone.utc).isoformat()),
    )
    conn.commit()
    conn.close()
    return session_id


VALID_STATUSES = ("sin iniciar", "en proceso", "terminado")


CAREERS = (
    "Ingeniería en Sistemas Computacionales",
    "Ingeniería Mecatrónica",
    "Ingeniería Mecánica",
    "Ingeniería en Materiales",
    "Ingeniería Eléctrica",
    "Ingeniería Electrónica",
    "Ingeniería Industrial",
    "Ingeniería en Gestión Empresarial",
    "Distancia Industrial (77)",
    "Distancia Industrial (99)",
    "Distancia Sistemas",
    "Distancia Gestión",
)

PERSON_NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ\s.'’-]+$")
CONTROL_NUMBER_RE = re.compile(r"^C?\d{8}$")
INSTITUTIONAL_EMAIL_RE = re.compile(r"^([a-z]?)(\d{8})@saltillo\.tecnm\.mx$")
PHONE_RE = re.compile(r"^\d{10}$")
ADMIN_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def now_local_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def days_until(deadline_str):
    deadline = datetime.strptime(deadline_str, "%Y-%m-%d").date()
    return (deadline - date.today()).days


def is_past_date(deadline_str):
    try:
        deadline = datetime.strptime(deadline_str, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return True
    return deadline < date.today()


def compute_priority(complexity, deadline_str):
    d = days_until(deadline_str)
    if d > 14:
        return "baja"
    if d <= 1 or complexity >= 9:
        return "crítico"
    if d <= 3 or complexity >= 7:
        return "alta"
    if d <= 7 or complexity >= 4:
        return "media"
    return "baja"


PROFESSOR_NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿÑñ\s.'\-]*$")


REQUIRED_FIELDS = (
    ("title", "Título"),
    ("subject", "Materia"),
    ("professor", "Profesor"),
    ("category", "Categoría"),
    ("deadline", "Fecha de entrega"),
)


def missing_required_fields(data):
    return [label for key, label in REQUIRED_FIELDS if not str(data.get(key) or "").strip()]


def is_valid_professor_name(value):
    return bool(PROFESSOR_NAME_RE.match(value or ""))


def serialize_task(row):
    d = days_until(row["deadline"])
    keys = row.keys()
    return {
        "id": row["id"],
        "title": row["title"],
        "description": row["description"] or "",
        "subject": row["subject"],
        "professor": row["professor"] or "",
        "category": row["category"] or "" if "category" in keys else "",
        "type": row["type"],
        "complexity": row["complexity"],
        "deadline": row["deadline"],
        "status": row["status"],
        "completedAt": row["completed_at"] if "completed_at" in keys else None,
        "priority": compute_priority(row["complexity"], row["deadline"]),
        "daysUntilDeadline": d,
        "collaborators": collaborators_from_json(row["collaborators"]) if "collaborators" in keys else [],
        "reminderAt": row["reminder_at"] if "reminder_at" in keys else None,
    }


def fetch_task_with_reminder(conn, task_id):
    return conn.execute(
        "SELECT t.*, r.remind_at AS reminder_at FROM vista_compat_tareas t "
        "LEFT JOIN vista_compat_recordatorios r ON r.task_id = t.id "
        "WHERE t.id = ?",
        (task_id,),
    ).fetchone()


def fetch_tasks_with_reminder(conn, user_id):
    return conn.execute(
        "SELECT t.*, r.remind_at AS reminder_at FROM vista_compat_tareas t "
        "LEFT JOIN vista_compat_recordatorios r ON r.task_id = t.id "
        "WHERE t.user_id = ? ORDER BY t.deadline ASC",
        (user_id,),
    ).fetchall()


def split_collaborator(item):
    if isinstance(item, dict):
        name = str(item.get("name") or "").strip()
        control = str(item.get("controlNumber") or item.get("control_number") or "").strip().upper()
    else:
        name = str(item).strip()
        control = ""
    return name, control


def parse_collaborators(data):
    raw = data.get("collaborators", [])
    if isinstance(raw, str):
        raw = [c.strip() for c in raw.split(",") if c.strip()]
    if not isinstance(raw, list):
        return []

    conn = get_db()
    result, seen = [], set()
    for item in raw:
        name, control = split_collaborator(item)
        if control:
            row = conn.execute(
                "SELECT name, control_number FROM vista_compat_usuarios WHERE control_number = ?", (control,)
            ).fetchone()
            if row:
                name, control = row["name"], row["control_number"]
            else:
                control = ""
        elif name:
            rows = conn.execute(
                "SELECT name, control_number FROM vista_compat_usuarios WHERE name = ?", (name,)
            ).fetchall()
            if len(rows) == 1 and rows[0]["control_number"]:
                control = rows[0]["control_number"]
        if not name:
            continue
        key = (name, control)
        if key in seen:
            continue
        seen.add(key)
        result.append({"name": name, "controlNumber": control})
    conn.close()
    return result[:20]


def collaborators_to_json(lst):
    return json.dumps(lst, ensure_ascii=False)


def collaborators_from_json(raw):
    if not raw:
        return []
    try:
        val = json.loads(raw)
    except (TypeError, ValueError):
        return []
    if not isinstance(val, list):
        return []
    result = []
    for item in val:
        name, control = split_collaborator(item)
        if name:
            result.append({"name": name, "controlNumber": control})
    return result


def compute_reminder_date(deadline_str):
    deadline = datetime.strptime(deadline_str, "%Y-%m-%d").date()
    today = date.today()
    remind = deadline - timedelta(days=2)
    if remind < today:
        remind = today if deadline >= today else deadline
    return remind.isoformat()


def upsert_reminder(conn, task_id, user_id, deadline_str):
    conn.execute("DELETE FROM vista_compat_recordatorios WHERE task_id = ?", (task_id,))
    conn.execute(
        "INSERT INTO vista_compat_recordatorios (id, task_id, user_id, remind_at, created_at) VALUES (?,?,?,?,?)",
        (
            str(uuid.uuid4()),
            task_id,
            user_id,
            compute_reminder_date(deadline_str),
            datetime.now(timezone.utc).isoformat(),
        ),
    )


def recalc_progress(conn, user_id):
    total = conn.execute("SELECT COUNT(*) AS c FROM vista_compat_tareas WHERE user_id = ?", (user_id,)).fetchone()["c"]
    done = conn.execute(
        "SELECT COUNT(*) AS c FROM vista_compat_tareas WHERE user_id = ? AND status = 'terminado'", (user_id,)
    ).fetchone()["c"]
    pct = round((done / total) * 100, 1) if total else 0.0
    pendientes = total - done
    conn.execute(
        "INSERT INTO controles_progreso_tareas(id_usuario,fecha_ultima_actualizacion) VALUES (?, ?) "
        "ON CONFLICT(id_usuario) DO UPDATE SET fecha_ultima_actualizacion=excluded.fecha_ultima_actualizacion",
        (user_id, datetime.now(timezone.utc).isoformat()),
    )
    return {"total": total, "completadas": done, "pendientes": pendientes, "porcentaje": pct}


def load_template(name):
    with open(os.path.join(TEMPLATES_DIR, name), "r", encoding="utf-8") as f:
        return f.read()


def render(name, **tokens):
    html = load_template(name)
    for key, value in tokens.items():
        html = html.replace("{{" + key + "}}", value)
    return html


def escape_html(text):
    return (
        (text or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def flash_html(messages):
    if not messages:
        return ""
    items = "".join(
        f'<div class="flash flash-{cat}">{escape_html(msg)}</div>' for cat, msg in messages
    )
    return f'<div class="flash-messages">{items}</div>'


ROUTES = []


def route(method, pattern):
    regex = re.compile("^" + pattern + "$")

    def decorator(func):
        ROUTES.append((method, regex, func))
        return func

    return decorator


class Request:
    def __init__(self, handler, method, path, query, params):
        self.handler = handler
        self.method = method
        self.path = path
        self.query = query
        self.params = params
        self.cookies = http.cookies.SimpleCookie()
        cookie_header = handler.headers.get("Cookie")
        if cookie_header:
            self.cookies.load(cookie_header)

        self._body = None
        length = int(handler.headers.get("Content-Length", 0))
        if length:
            self._body = handler.rfile.read(length)

    def form(self):
        if not self._body:
            return {}
        parsed = parse_qs(self._body.decode("utf-8"))
        return {k: v[0] for k, v in parsed.items()}

    def json(self):
        if not self._body:
            return {}
        return json.loads(self._body.decode("utf-8"))

    def get_cookie(self, name):
        if name in self.cookies:
            return self.cookies[name].value
        return None

    def current_user_id(self):
        session_id = self.get_cookie("session_id")
        if not session_id:
            return None
        conn = get_db()
        row = conn.execute(
            "SELECT s.user_id FROM vista_compat_sesiones s JOIN vista_compat_usuarios u ON u.id = s.user_id "
            "WHERE s.id = ? AND u.active = 1",
            (session_id,),
        ).fetchone()
        conn.close()
        return row["user_id"] if row else None


class Response:
    def __init__(self, status=200, body=b"", headers=None, is_json=False, is_text=True):
        self.status = status
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.body = body
        self.headers = headers or {}
        if is_json:
            self.headers.setdefault("Content-Type", "application/json; charset=utf-8")
        elif is_text and "Content-Type" not in self.headers:
            self.headers.setdefault("Content-Type", "text/html; charset=utf-8")
        self.cookies_to_set = []

    def set_cookie(self, name, value, max_age=None, delete=False):
        parts = [f"{name}={value}", "Path=/", "HttpOnly"]
        if delete:
            parts.append("Max-Age=0")
        elif max_age is not None:
            parts.append(f"Max-Age={max_age}")
        self.cookies_to_set.append("; ".join(parts))


def redirect(location, flash_messages=None):
    resp = Response(status=302, headers={"Location": location})
    if flash_messages is not None:
        payload = json.dumps(flash_messages)
        resp.set_cookie("flash", _encode_cookie_value(payload))
    return resp


def _encode_cookie_value(text):
    return text.encode("utf-8").hex()


def _decode_cookie_value(hex_text):
    try:
        return bytes.fromhex(hex_text).decode("utf-8")
    except Exception:
        return None


def json_response(data, status=200):
    return Response(status=status, body=json.dumps(data), is_json=True)


def require_login(req):
    return req.current_user_id()


def get_user_role(user_id):
    conn = get_db()
    row = conn.execute("SELECT role FROM vista_compat_usuarios WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return row["role"] if row else None


def home_path(user_id):
    return {"admin": "/admin", "profesor": "/profesor"}.get(get_user_role(user_id), "/dashboard")


def require_admin(req):
    user_id = req.current_user_id()
    if not user_id:
        return None, json_response({"error": "No autenticado"}, 401)
    if get_user_role(user_id) != "admin":
        return None, json_response({"error": "No tienes permiso para esta acción."}, 403)
    return user_id, None


@route("GET", r"/")
def index(req):
    user_id = req.current_user_id()
    if user_id:
        return redirect(home_path(user_id))
    return redirect("/login")


@route("GET", r"/login")
def login_page(req):
    user_id = req.current_user_id()
    if user_id:
        return redirect(home_path(user_id))

    messages = []
    raw = req.get_cookie("flash")
    resp = Response(body=render("login.html", FLASH=""))
    if raw:
        decoded = _decode_cookie_value(raw)
        if decoded:
            try:
                messages = json.loads(decoded)
            except Exception:
                messages = []
    resp.body = render("login.html", FLASH=flash_html(messages)).encode("utf-8")
    if raw:
        resp.set_cookie("flash", "", delete=True)
    return resp


@route("POST", r"/login")
def do_login(req):
    form = req.form()
    email = form.get("email", "").strip().lower()
    password = form.get("password", "")

    conn = get_db()
    user = conn.execute("SELECT * FROM vista_compat_usuarios WHERE email = ?", (email,)).fetchone()
    conn.close()

    if not user or not verify_password(password, user["password_hash"]):
        return Response(body=render("login.html", FLASH=flash_html([["error", "Correo o contraseña incorrectos."]])), status=401)

    if not user["active"]:
        return Response(body=render("login.html", FLASH=flash_html([["error", "Tu cuenta está desactivada. Contacta al administrador."]])), status=403)

    session_id = create_session(user["id"])
    conn = get_db()
    previous = conn.execute(
        "SELECT created_at FROM vista_compat_notificaciones WHERE user_id = ? AND type = 'inicio_sesion' "
        "ORDER BY created_at DESC LIMIT 1", (user["id"],)
    ).fetchone()
    previous_text = ("Inicio de sesión anterior: " + previous["created_at"][:19].replace("T", " ") + " UTC."
                     if previous else "Este es tu primer inicio de sesión registrado en las notificaciones.")
    add_notification(conn, user["id"], "inicio_sesion", "Inicio de sesión", previous_text)
    conn.commit()
    conn.close()

    resp = redirect(home_path(user["id"]))
    resp.set_cookie("session_id", session_id)
    resp.set_cookie("user_name", _encode_cookie_value(user["name"]))
    return resp


@route("POST", r"/register")
def register(req):
    form = req.form()
    first_name = " ".join(form.get("first_name", "").split())
    last_p = " ".join(form.get("last_name_p", "").split())
    last_m = " ".join(form.get("last_name_m", "").split())
    career = form.get("career", "").strip()
    semester = form.get("semester", "").strip()
    control = form.get("control_number", "").strip().upper()
    phone = form.get("phone", "").strip()
    email = form.get("email", "").strip().lower()
    confirm_email = form.get("confirm_email", "").strip().lower()
    password = form.get("password", "")
    confirm = form.get("confirm_password", "")

    required = (
        ("Nombre", first_name),
        ("Apellido paterno", last_p),
        ("Apellido materno", last_m),
        ("Carrera", career),
        ("Semestre", semester),
        ("Número de control", control),
        ("Número de teléfono", phone),
        ("Correo electrónico", email),
        ("Confirmar correo electrónico", confirm_email),
        ("Contraseña", password),
        ("Confirmar contraseña", confirm),
    )
    errors = []
    missing = [label for label, value in required if not value]
    if missing:
        errors.append("Falta rellenar: " + ", ".join(missing) + ".")
    else:
        for label, value in (("Nombre", first_name), ("Apellido paterno", last_p), ("Apellido materno", last_m)):
            if not PERSON_NAME_RE.match(value):
                errors.append(f"{label}: solo se permiten letras.")
            elif contains_admin_word(value):
                errors.append(f'{label}: no puede contener la palabra "admin".')
        if career not in CAREERS:
            errors.append("Selecciona una carrera de la lista.")
        if not semester.isdigit() or not 1 <= int(semester) <= 14:
            errors.append("Selecciona un semestre válido.")
        if not CONTROL_NUMBER_RE.match(control):
            errors.append("Número de control: debe tener 8 dígitos, o la letra C seguida de 8 dígitos.")
        if not PHONE_RE.match(phone):
            errors.append("Número de teléfono: debe tener 10 dígitos.")
        institutional = INSTITUTIONAL_EMAIL_RE.match(email)
        if not institutional:
            errors.append(
                "Correo electrónico: debe ser institucional, con el formato número_de_control@saltillo.tecnm.mx."
            )
        elif CONTROL_NUMBER_RE.match(control) and institutional.group(2) != control[-8:]:
            errors.append("El correo institucional debe corresponder a tu número de control.")
        elif email != confirm_email:
            errors.append("Los correos electrónicos no coinciden.")
        if len(password) < 6:
            errors.append("La contraseña debe tener al menos 6 caracteres.")
        elif password != confirm:
            errors.append("Las contraseñas no coinciden.")

    conn = get_db()
    if not errors:
        if conn.execute("SELECT id FROM vista_compat_usuarios WHERE email = ?", (email,)).fetchone():
            errors.append("Ya existe una cuenta con ese correo.")
        if conn.execute("SELECT id FROM vista_compat_usuarios WHERE control_number = ?", (control,)).fetchone():
            errors.append("Ya existe una cuenta con ese número de control.")
        if phone and conn.execute("SELECT id FROM vista_compat_usuarios WHERE phone = ?", (phone,)).fetchone():
            errors.append("Ya existe una cuenta con ese número de teléfono.")
    if errors:
        conn.close()
        return redirect("/login?register=1", flash_messages=[["error", m] for m in errors])

    full_name = f"{first_name} {last_p} {last_m}"
    conn.execute(
        "INSERT INTO vista_compat_usuarios (id, name, email, password_hash, career, semester, created_at, "
        "first_name, last_name_paterno, last_name_materno, control_number, phone) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            str(uuid.uuid4()),
            full_name,
            email,
            hash_password(password),
            career,
            semester,
            datetime.now(timezone.utc).isoformat(),
            first_name,
            last_p,
            last_m,
            control,
            phone,
        ),
    )
    conn.commit()
    conn.close()

    return redirect(
        "/login",
        flash_messages=[["success", "Cuenta creada correctamente. Inicia sesión con tu correo y contraseña."]],
    )


@route("GET", r"/logout")
def logout(req):
    session_id = req.get_cookie("session_id")
    if session_id:
        conn = get_db()
        conn.execute("DELETE FROM vista_compat_sesiones WHERE id = ?", (session_id,))
        conn.commit()
        conn.close()
    resp = redirect("/login")
    resp.set_cookie("session_id", "", delete=True)
    resp.set_cookie("user_name", "", delete=True)
    return resp


@route("GET", r"/dashboard")
def dashboard(req):
    user_id = req.current_user_id()
    if not user_id:
        return redirect("/login")
    role = get_user_role(user_id)
    if role in ("admin", "profesor"):
        return redirect(home_path(user_id))
    raw_name = req.get_cookie("user_name")
    name = _decode_cookie_value(raw_name) if raw_name else "Usuario"
    return Response(
        body=render("dashboard.html", USER_NAME=escape_html(name), TODAY=date.today().isoformat())
    )



def clean_text(value):
    return " ".join(str(value or "").split())


def validate_admin_form(data, existing=None):
    role = str(data.get("role") or "estudiante").strip()
    if role not in ("estudiante", "admin", "profesor"):
        return ["Rol no válido."], None

    first = clean_text(data.get("first_name"))
    last_p = clean_text(data.get("last_name_p"))
    last_m = clean_text(data.get("last_name_m"))
    career = str(data.get("career") or "").strip()
    semester = str(data.get("semester") or "").strip()
    control = str(data.get("control_number") or "").strip().upper()
    phone = str(data.get("phone") or "").strip()
    email = str(data.get("email") or "").strip().lower()
    password = str(data.get("password") or "")

    creating = existing is None
    legacy = (not creating) and existing["role"] == "estudiante" and not existing["control_number"]

    if role in ("admin", "profesor"):
        required = [("Nombre", first), ("Apellido paterno", last_p), ("Correo electrónico", email)]
    elif legacy:
        required = [("Nombre", first), ("Correo electrónico", email)]
    else:
        required = [
            ("Nombre", first),
            ("Apellido paterno", last_p),
            ("Apellido materno", last_m),
            ("Carrera", career),
            ("Semestre", semester),
            ("Número de control", control),
            ("Número de teléfono", phone),
            ("Correo electrónico", email),
        ]
    if creating:
        required.append(("Contraseña", password))

    missing = [label for label, value in required if not value]
    if missing:
        return ["Falta rellenar: " + ", ".join(missing) + "."], None

    errors = []
    for label, value in (("Nombre", first), ("Apellido paterno", last_p), ("Apellido materno", last_m)):
        if value and not PERSON_NAME_RE.match(value):
            errors.append(f"{label}: solo se permiten letras.")
        elif value and role == "estudiante" and contains_admin_word(value):
            errors.append(f'{label}: no puede contener la palabra "admin".')

    if role == "estudiante":
        old_career = (existing["career"] or "") if existing else ""
        if career and career not in CAREERS and career != old_career:
            errors.append("Selecciona una carrera de la lista.")
        if semester and (not semester.isdigit() or not 1 <= int(semester) <= 14):
            errors.append("Selecciona un semestre válido.")
        if control and not CONTROL_NUMBER_RE.match(control):
            errors.append("Número de control: debe tener 8 dígitos, o la letra C seguida de 8 dígitos.")
        if phone and not PHONE_RE.match(phone):
            errors.append("Número de teléfono: debe tener 10 dígitos.")
        if not (existing and email == existing["email"]):
            institutional = INSTITUTIONAL_EMAIL_RE.match(email)
            if not institutional:
                errors.append(
                    "Correo electrónico: debe ser institucional, con el formato número_de_control@saltillo.tecnm.mx."
                )
            elif control and CONTROL_NUMBER_RE.match(control) and institutional.group(2) != control[-8:]:
                errors.append("El correo institucional debe corresponder al número de control.")
    else:
        career = semester = control = phone = ""
        if not ADMIN_EMAIL_RE.match(email):
            errors.append("Correo electrónico: formato no válido.")

    if password and len(password) < 6:
        errors.append("La contraseña debe tener al menos 6 caracteres.")

    if errors:
        return errors, None

    return [], {
        "role": role,
        "first_name": first,
        "last_name_p": last_p,
        "last_name_m": last_m,
        "name": " ".join(part for part in (first, last_p, last_m) if part),
        "career": career or None,
        "semester": semester or None,
        "control_number": control or None,
        "phone": phone or None,
        "email": email,
        "password": password,
    }


def duplicate_user_errors(conn, email, control, exclude_id=None, phone=None):
    errors = []
    row = conn.execute("SELECT id FROM vista_compat_usuarios WHERE email = ?", (email,)).fetchone()
    if row and row["id"] != exclude_id:
        errors.append("Ya existe una cuenta con ese correo.")
    if control:
        row = conn.execute("SELECT id FROM vista_compat_usuarios WHERE control_number = ?", (control,)).fetchone()
        if row and row["id"] != exclude_id:
            errors.append("Ya existe una cuenta con ese número de control.")
    if phone:
        row = conn.execute("SELECT id FROM vista_compat_usuarios WHERE phone = ?", (phone,)).fetchone()
        if row and row["id"] != exclude_id:
            errors.append("Ya existe una cuenta con ese número de teléfono.")
    return errors


def other_active_admins(conn, exclude_id):
    return conn.execute(
        "SELECT COUNT(*) AS c FROM vista_compat_usuarios WHERE role = 'admin' AND active = 1 AND id != ?", (exclude_id,)
    ).fetchone()["c"]


def serialize_admin_user(row, admin_id):
    return {
        "id": row["id"],
        "name": row["name"],
        "firstName": row["first_name"] or "",
        "lastNameP": row["last_name_paterno"] or "",
        "lastNameM": row["last_name_materno"] or "",
        "career": row["career"] or "",
        "semester": row["semester"] or "",
        "controlNumber": row["control_number"] or "",
        "phone": row["phone"] or "",
        "email": row["email"],
        "role": row["role"],
        "active": bool(row["active"]),
        "createdAt": row["created_at"],
        "tasksCount": row["tasks_count"] if "tasks_count" in row.keys() else 0,
        "isSelf": row["id"] == admin_id,
    }


USER_WITH_TASKS_SQL = (
    "SELECT u.*, (SELECT COUNT(*) FROM vista_compat_tareas t WHERE t.user_id = u.id) AS tasks_count FROM vista_compat_usuarios u"
)


@route("GET", r"/admin")
def admin_page(req):
    user_id = req.current_user_id()
    if not user_id:
        return redirect("/login")
    if get_user_role(user_id) != "admin":
        return redirect(home_path(user_id))
    raw_name = req.get_cookie("user_name")
    name = _decode_cookie_value(raw_name) if raw_name else "Administrador"
    career_options = "".join(
        f'<option value="{escape_html(c)}">{escape_html(c)}</option>' for c in CAREERS
    )
    semester_options = "".join(
        f'<option value="{i}">{i}° Semestre</option>' for i in range(1, 15)
    )
    return Response(
        body=render(
            "admin.html",
            USER_NAME=escape_html(name),
            CAREER_OPTIONS=career_options,
            SEMESTER_OPTIONS=semester_options,
        )
    )


@route("GET", r"/api/admin/users")
def api_admin_list_users(req):
    admin_id, error = require_admin(req)
    if error:
        return error

    q = (req.query.get("q", [""])[0] or "").strip()
    career = (req.query.get("career", [""])[0] or "").strip()
    status = (req.query.get("status", [""])[0] or "").strip()
    role = (req.query.get("role", [""])[0] or "").strip()

    sql = USER_WITH_TASKS_SQL + " WHERE 1 = 1"
    params = []
    if q:
        sql += " AND (u.name LIKE ? OR u.email LIKE ? OR u.control_number LIKE ? OR u.phone LIKE ?)"
        params += [f"%{q}%"] * 4
    if career:
        sql += " AND u.career = ?"
        params.append(career)
    if status == "activo":
        sql += " AND u.active = 1"
    elif status == "desactivado":
        sql += " AND u.active = 0"
    if role in ("estudiante", "admin", "profesor"):
        sql += " AND u.role = ?"
        params.append(role)
    sql += " ORDER BY u.name COLLATE NOCASE"

    conn = get_db()
    rows = conn.execute(sql, params).fetchall()
    counts = conn.execute(
        "SELECT COUNT(*) AS total, "
        "COALESCE(SUM(active = 1), 0) AS activos, "
        "COALESCE(SUM(active = 0), 0) AS desactivados, "
        "COALESCE(SUM(role = 'admin'), 0) AS admins FROM vista_compat_usuarios"
    ).fetchone()
    conn.close()
    return json_response(
        {
            "users": [serialize_admin_user(r, admin_id) for r in rows],
            "summary": {
                "total": counts["total"],
                "activos": counts["activos"],
                "desactivados": counts["desactivados"],
                "admins": counts["admins"],
            },
        }
    )


@route("POST", r"/api/admin/users")
def api_admin_create_user(req):
    admin_id, error = require_admin(req)
    if error:
        return error

    errors, clean = validate_admin_form(req.json())
    conn = get_db()
    if not errors:
        errors = duplicate_user_errors(conn, clean["email"], clean["control_number"], phone=clean["phone"])
    if errors:
        conn.close()
        return json_response({"errors": errors}, 400)

    user_id = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO vista_compat_usuarios (id, name, email, password_hash, career, semester, created_at, "
        "first_name, last_name_paterno, last_name_materno, control_number, phone, role, active) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)",
        (
            user_id,
            clean["name"],
            clean["email"],
            hash_password(clean["password"]),
            clean["career"],
            clean["semester"],
            datetime.now(timezone.utc).isoformat(),
            clean["first_name"],
            clean["last_name_p"],
            clean["last_name_m"],
            clean["control_number"],
            clean["phone"],
            clean["role"],
        ),
    )
    add_notification(conn, admin_id, "usuario_creado", "Usuario agregado",
                     f'Se agregó correctamente la cuenta de {clean["name"]}.')
    conn.commit()
    row = conn.execute(USER_WITH_TASKS_SQL + " WHERE u.id = ?", (user_id,)).fetchone()
    conn.close()
    return json_response(serialize_admin_user(row, admin_id), 201)


@route("PUT", r"/api/admin/users/(?P<user_id>[\w-]+)")
def api_admin_update_user(req):
    admin_id, error = require_admin(req)
    if error:
        return error

    target_id = req.params["user_id"]
    conn = get_db()
    row = conn.execute("SELECT * FROM vista_compat_usuarios WHERE id = ?", (target_id,)).fetchone()
    if not row:
        conn.close()
        return json_response({"error": "Usuario no encontrado."}, 404)

    errors, clean = validate_admin_form(req.json(), existing=row)
    if not errors:
        if target_id == admin_id and clean["role"] != row["role"]:
            errors.append("No puedes cambiar tu propio rol.")
        if row["role"] == "admin" and clean["role"] != "admin" and other_active_admins(conn, target_id) == 0:
            errors.append("Debe quedar al menos un administrador activo.")
        errors += duplicate_user_errors(conn, clean["email"], clean["control_number"], exclude_id=target_id, phone=clean["phone"])
    if errors:
        conn.close()
        return json_response({"errors": errors}, 400)

    password_hash = hash_password(clean["password"]) if clean["password"] else row["password_hash"]
    conn.execute(
        "UPDATE vista_compat_usuarios SET name = ?, email = ?, password_hash = ?, career = ?, semester = ?, "
        "first_name = ?, last_name_paterno = ?, last_name_materno = ?, control_number = ?, phone = ?, role = ? "
        "WHERE id = ?",
        (
            clean["name"],
            clean["email"],
            password_hash,
            clean["career"],
            clean["semester"],
            clean["first_name"],
            clean["last_name_p"],
            clean["last_name_m"],
            clean["control_number"],
            clean["phone"],
            clean["role"],
            target_id,
        ),
    )
    if clean["password"] or clean["email"] != row["email"]:
        keep = req.get_cookie("session_id") if target_id == admin_id else ""
        conn.execute("DELETE FROM vista_compat_sesiones WHERE user_id = ? AND id != ?", (target_id, keep or ""))
    add_notification(conn, admin_id, "usuario_actualizado", "Usuario actualizado",
                     f'Se actualizó la información de {clean["name"]}.')
    conn.commit()
    updated = conn.execute(USER_WITH_TASKS_SQL + " WHERE u.id = ?", (target_id,)).fetchone()
    conn.close()
    return json_response(serialize_admin_user(updated, admin_id))


@route("POST", r"/api/admin/users/(?P<user_id>[\w-]+)/status")
def api_admin_set_user_status(req):
    admin_id, error = require_admin(req)
    if error:
        return error

    target_id = req.params["user_id"]
    active = bool(req.json().get("active"))
    conn = get_db()
    row = conn.execute("SELECT * FROM vista_compat_usuarios WHERE id = ?", (target_id,)).fetchone()
    if not row:
        conn.close()
        return json_response({"error": "Usuario no encontrado."}, 404)
    if not active:
        if target_id == admin_id:
            conn.close()
            return json_response({"error": "No puedes desactivar tu propia cuenta."}, 400)
        if row["role"] == "admin" and other_active_admins(conn, target_id) == 0:
            conn.close()
            return json_response({"error": "Debe quedar al menos un administrador activo."}, 400)

    conn.execute("UPDATE vista_compat_usuarios SET active = ? WHERE id = ?", (1 if active else 0, target_id))
    if not active:
        conn.execute("DELETE FROM vista_compat_sesiones WHERE user_id = ?", (target_id,))
    add_notification(conn, admin_id, "usuario_activado" if active else "usuario_desactivado",
                     "Cuenta activada" if active else "Cuenta desactivada",
                     f'La cuenta de {row["name"]} fue ' + ("activada." if active else "desactivada."))
    conn.commit()
    updated = conn.execute(USER_WITH_TASKS_SQL + " WHERE u.id = ?", (target_id,)).fetchone()
    conn.close()
    return json_response(serialize_admin_user(updated, admin_id))


@route("DELETE", r"/api/admin/users/(?P<user_id>[\w-]+)")
def api_admin_delete_user(req):
    admin_id, error = require_admin(req)
    if error:
        return error

    target_id = req.params["user_id"]
    conn = get_db()
    row = conn.execute("SELECT * FROM vista_compat_usuarios WHERE id = ?", (target_id,)).fetchone()
    if not row:
        conn.close()
        return json_response({"error": "Usuario no encontrado."}, 404)
    if target_id == admin_id:
        conn.close()
        return json_response({"error": "No puedes eliminar tu propia cuenta."}, 400)
    if row["role"] == "admin" and other_active_admins(conn, target_id) == 0:
        conn.close()
        return json_response({"error": "Debe quedar al menos un administrador activo."}, 400)

    tasks_deleted = conn.execute(
        "SELECT COUNT(*) AS c FROM vista_compat_tareas WHERE user_id = ?", (target_id,)
    ).fetchone()["c"]
    conn.execute("DELETE FROM vista_compat_usuarios WHERE id = ?", (target_id,))
    add_notification(conn, admin_id, "usuario_eliminado", "Cuenta eliminada",
                     f'La cuenta de {row["name"]} se eliminó definitivamente.')
    conn.commit()
    conn.close()
    return json_response({"deleted": True, "tasks": tasks_deleted})


def contains_admin_word(value):
    return "admin" in fold_text(value)


def fold_text(value):
    return "".join(
        c for c in unicodedata.normalize("NFD", value.lower()) if unicodedata.category(c) != "Mn"
    )


def subjects_for_career(career):
    catalog = MATERIAS_POR_CARRERA.get(ALIAS_CARRERAS.get(career, career))
    if catalog:
        return list(catalog), True
    everything = {m for subjects in MATERIAS_POR_CARRERA.values() for m in subjects}
    return sorted(everything, key=fold_text), False


@route("GET", r"/api/subjects")
def api_subjects(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)

    conn = get_db()
    row = conn.execute("SELECT career FROM vista_compat_usuarios WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    career = (row["career"] if row else "") or ""
    subjects, complete = subjects_for_career(career)
    return json_response({"career": career, "subjects": subjects, "complete": complete})


@route("GET", r"/api/tasks")
def api_list_tasks(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    conn = get_db()
    rows = fetch_tasks_with_reminder(conn, user_id)
    conn.close()
    return json_response([serialize_task(r) for r in rows])


def plural_days(n):
    return f"{n} día" if n == 1 else f"{n} días"


def format_date_es(iso_date):
    return datetime.strptime(iso_date, "%Y-%m-%d").strftime("%d/%m/%Y")


def add_notification(conn, user_id, kind, title, message, task_id=None, dedupe_key=None, read=False):
    now = datetime.now(timezone.utc).isoformat()
    cur = conn.execute(
        "INSERT OR IGNORE INTO vista_compat_notificaciones "
        "(id, user_id, type, task_id, title, message, dedupe_key, created_at, read_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (str(uuid.uuid4()), user_id, kind, task_id, title, message, dedupe_key, now, now if read else None),
    )
    return cur.rowcount > 0


def generate_critical_notifications(conn, user_id):
    today = date.today().isoformat()
    rows = conn.execute(
        "SELECT id, title, deadline, complexity FROM vista_compat_tareas WHERE user_id = ? AND status != 'terminado'",
        (user_id,),
    ).fetchall()
    for r in rows:
        if compute_priority(r["complexity"], r["deadline"]) != "crítico":
            continue
        d = days_until(r["deadline"])
        if d < 0:
            message = f'"{r["title"]}" venció hace {plural_days(-d)}. Entrégala cuanto antes.'
        elif d == 0:
            message = f'"{r["title"]}" vence hoy.'
        elif d == 1:
            message = f'"{r["title"]}" vence mañana.'
        else:
            message = f'"{r["title"]}" vence en {plural_days(d)}.'
        add_notification(
            conn, user_id, "critica", "Tarea crítica", message, r["id"], f"critica:{r['id']}:{today}"
        )
    conn.execute(
        "DELETE FROM vista_compat_notificaciones WHERE user_id = ? AND id NOT IN "
        "(SELECT id FROM vista_compat_notificaciones WHERE user_id = ? ORDER BY created_at DESC LIMIT 60)",
        (user_id, user_id),
    )


@route("GET", r"/api/notifications")
def api_notifications(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)

    conn = get_db()
    generate_critical_notifications(conn, user_id)
    conn.commit()
    rows = conn.execute(
        "SELECT * FROM vista_compat_notificaciones WHERE user_id = ? ORDER BY created_at DESC LIMIT 30", (user_id,)
    ).fetchall()
    unread = conn.execute(
        "SELECT COUNT(*) AS c FROM vista_compat_notificaciones WHERE user_id = ? AND read_at IS NULL", (user_id,)
    ).fetchone()["c"]
    conn.close()
    return json_response(
        {
            "notifications": [
                {
                    "id": r["id"],
                    "type": r["type"],
                    "taskId": r["task_id"],
                    "title": r["title"],
                    "message": r["message"],
                    "createdAt": r["created_at"],
                    "read": r["read_at"] is not None,
                }
                for r in rows
            ],
            "unread": unread,
        }
    )


@route("POST", r"/api/notifications/read")
def api_notifications_read(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)

    data = req.json()
    now = datetime.now(timezone.utc).isoformat()
    conn = get_db()
    if data.get("all"):
        conn.execute(
            "UPDATE vista_compat_notificaciones SET read_at = ? WHERE user_id = ? AND read_at IS NULL", (now, user_id)
        )
    else:
        ids = data.get("ids", [])
        if isinstance(ids, list):
            for notif_id in ids[:100]:
                conn.execute(
                    "UPDATE vista_compat_notificaciones SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL",
                    (now, str(notif_id), user_id),
                )
    conn.commit()
    conn.close()
    return json_response({"ok": True})


@route("GET", r"/api/profile")
def api_profile(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    conn = get_db()
    row = conn.execute("SELECT name, first_name, last_name_paterno, last_name_materno, career, semester, email, phone, avatar_data FROM vista_compat_usuarios WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return json_response({"error": "Usuario no encontrado."}, 404)
    return json_response({k: row[k] or "" for k in row.keys()})


@route("PUT", r"/api/profile")
def api_update_profile(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    try:
        data = req.json()
    except (ValueError, UnicodeDecodeError):
        return json_response({"error": "Datos inválidos."}, 400)
    if not isinstance(data, dict):
        return json_response({"error": "Datos inválidos."}, 400)
    conn = get_db()
    old = conn.execute("SELECT * FROM vista_compat_usuarios WHERE id = ?", (user_id,)).fetchone()
    if not old:
        conn.close()
        return json_response({"error": "Usuario no encontrado."}, 404)
    first = str(data.get("first_name", "")).strip()
    paternal = str(data.get("last_name_paterno", "")).strip()
    maternal = str(data.get("last_name_materno", "")).strip()
    phone = str(data.get("phone", "")).strip()
    semester = str(data.get("semester", old["semester"] or "")).strip()
    errors = []
    if not semester.isdigit() or not (1 <= int(semester) <= 14):
        errors.append("Selecciona un semestre válido (1 a 14).")
    for label, value in (("Nombre", first), ("Apellido paterno", paternal), ("Apellido materno", maternal)):
        if not value or not PERSON_NAME_RE.fullmatch(value):
            errors.append(f"{label}: solo se permiten letras y signos admitidos en nombres.")
        elif contains_admin_word(value):
            errors.append(f'{label}: no puede contener la palabra "admin".')
    if not PHONE_RE.fullmatch(phone):
        errors.append("Número de teléfono: debe contener exactamente 10 dígitos.")
    elif conn.execute("SELECT 1 FROM vista_compat_usuarios WHERE phone = ? AND id != ?", (phone, user_id)).fetchone():
        errors.append("Ya existe una cuenta con ese número de teléfono.")
    avatar = old["avatar_data"] or ""
    if "avatar_data" in data:
        candidate = data["avatar_data"]
        if not isinstance(candidate, str):
            errors.append("La imagen no es válida.")
        elif not candidate:
            avatar = ""
        elif len(candidate) > 300000:
            errors.append("La imagen es demasiado grande (máximo 150 KB).")
        else:
            match = re.fullmatch(r"data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)", candidate)
            if not match:
                errors.append("Solo se permiten imágenes PNG, JPG o WebP.")
            else:
                try:
                    raw = base64.b64decode(match.group(2), validate=True)
                    valid = ((match.group(1) == "png" and raw.startswith(b"\x89PNG\r\n\x1a\n")) or
                             (match.group(1) == "jpeg" and raw.startswith(b"\xff\xd8\xff")) or
                             (match.group(1) == "webp" and raw.startswith(b"RIFF") and raw[8:12] == b"WEBP"))
                    if not valid or len(raw) > 150 * 1024:
                        errors.append("La imagen debe ser válida y pesar como máximo 150 KB.")
                    else:
                        avatar = candidate
                except (ValueError, binascii.Error):
                    errors.append("La imagen no es válida.")
    if errors:
        conn.close()
        return json_response({"errors": errors}, 400)
    name = " ".join((first, paternal, maternal))
    try:
        conn.execute("UPDATE vista_compat_usuarios SET name=?, first_name=?, last_name_paterno=?, last_name_materno=?, phone=?, semester=?, avatar_data=? WHERE id=?",
                     (name, first, paternal, maternal, phone, semester, avatar, user_id))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return json_response({"errors": ["El teléfono ya está registrado."]}, 409)
    conn.close()
    return json_response({"ok": True})
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)



@route("GET", r"/api/progress")
def api_get_progress(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    conn = get_db()
    progress = recalc_progress(conn, user_id)
    conn.commit()
    conn.close()
    return json_response(progress)


def collaborator_subject_error(conn, collaborators, subject):
    """Check catalogued subjects against each collaborator's actual career."""
    subject = (subject or "").strip()
    if not any(subject in subjects for subjects in MATERIAS_POR_CARRERA.values()):
        return None  # Custom subjects have no verified career classification.
    for collaborator in collaborators:
        control = collaborator.get("controlNumber", "")
        if not control:
            return "No se pudo verificar la carrera de uno de los colaboradores."
        row = conn.execute("SELECT career FROM vista_compat_usuarios WHERE control_number = ?", (control,)).fetchone()
        if not row:
            return "No se pudo verificar la carrera de uno de los colaboradores."
        career = row["career"] or ""
        canonical = ALIAS_CARRERAS.get(career, career)
        if subject not in MATERIAS_POR_CARRERA.get(canonical, []):
            return f'No se puede añadir al colaborador: la materia "{subject}" no pertenece al plan de estudios de {career or "su carrera"}.'
    return None


@route("GET", r"/api/users/search")
def api_search_users(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    q = (req.query.get("q", [""])[0] or "").strip()
    subject = (req.query.get("subject", [""])[0] or "").strip()
    if not q:
        return json_response([])

    conn = get_db()
    rows = conn.execute(
        "SELECT id, name, career, semester, control_number FROM vista_compat_usuarios "
        "WHERE (name LIKE ? OR control_number LIKE ?) AND id != ? "
        "AND role = 'estudiante' AND active = 1 ORDER BY name LIMIT 8",
        (f"%{q}%", f"%{q}%", user_id),
    ).fetchall()
    conn.close()
    return json_response(
        [
            {
                "id": r["id"],
                "name": r["name"],
                "career": r["career"] or "",
                "eligible": (not any(subject in subjects for subjects in MATERIAS_POR_CARRERA.values())
                             or subject in MATERIAS_POR_CARRERA.get(ALIAS_CARRERAS.get(r["career"], r["career"]), [])),
                "semester": r["semester"] or "",
                "controlNumber": r["control_number"] or "",
            }
            for r in rows
        ]
    )


@route("POST", r"/api/tasks")
def api_create_task(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    data = req.json()
    missing = missing_required_fields(data)
    if missing:
        return json_response({"error": "Falta rellenar: " + ", ".join(missing) + "."}, 400)

    professor = (data.get("professor") or "").strip()
    if not is_valid_professor_name(professor):
        return json_response({"error": "Solo se permiten letras en este campo."}, 400)

    if is_past_date(data["deadline"]):
        return json_response(
            {"error": "La fecha de entrega no puede ser anterior al día de hoy."}, 400
        )

    task_id = str(uuid.uuid4())
    complexity = int(data.get("complexity", 5))
    task_type = data.get("type", "tarea")
    status = data.get("status", "sin iniciar")
    collaborators = parse_collaborators(data)
    if status not in VALID_STATUSES:
        return json_response({"error": "Estado inválido."}, 400)

    conn = get_db()
    eligibility_error = collaborator_subject_error(conn, collaborators, data.get("subject"))
    if eligibility_error:
        conn.close()
        return json_response({"error": eligibility_error}, 400)
    conn.execute(
        "INSERT INTO vista_compat_tareas (id, user_id, title, description, subject, professor, category, type, "
        "complexity, deadline, status, collaborators, created_at, completed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            task_id,
            user_id,
            data["title"],
            data.get("description", ""),
            data["subject"],
            professor,
            data["category"].strip(),
            task_type,
            complexity,
            data["deadline"],
            status,
            collaborators_to_json(collaborators),
            datetime.now(timezone.utc).isoformat(),
            now_local_str() if status == "terminado" else None,
        ),
    )
    upsert_reminder(conn, task_id, user_id, data["deadline"])
    recalc_progress(conn, user_id)
    add_notification(
        conn,
        user_id,
        "creada",
        "Tarea agregada",
        f'La tarea "{data["title"].strip()}" se agregó con éxito. Fecha de entrega: {format_date_es(data["deadline"])}.',
        task_id,
        read=True,
    )
    conn.commit()
    row = fetch_task_with_reminder(conn, task_id)
    conn.close()
    return json_response(serialize_task(row), 201)


@route("PUT", r"/api/tasks/(?P<task_id>[\w-]+)")
def api_update_task(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    task_id = req.params["task_id"]
    data = req.json()

    conn = get_db()
    row = conn.execute("SELECT * FROM vista_compat_tareas WHERE id = ? AND user_id = ?", (task_id, user_id)).fetchone()
    if not row:
        conn.close()
        return json_response({"error": "Tarea no encontrada"}, 404)

    complexity = int(data.get("complexity", row["complexity"]))
    deadline = data.get("deadline", row["deadline"])
    status = data.get("status", row["status"])
    professor = data.get("professor", row["professor"])
    collaborators = parse_collaborators(data) if "collaborators" in data else collaborators_from_json(row["collaborators"])
    eligibility_error = collaborator_subject_error(conn, collaborators, data.get("subject", row["subject"]))
    if eligibility_error:
        conn.close()
        return json_response({"error": eligibility_error}, 400)

    if any(k in data for k in ("title", "subject", "professor", "category", "deadline")):
        merged = {
            "title": data.get("title", row["title"]),
            "subject": data.get("subject", row["subject"]),
            "professor": data.get("professor", row["professor"]),
            "category": data.get("category", row["category"] if "category" in row.keys() else ""),
            "deadline": deadline,
        }
        missing = missing_required_fields(merged)
        if missing:
            conn.close()
            return json_response({"error": "Falta rellenar: " + ", ".join(missing) + "."}, 400)

    if not is_valid_professor_name(professor):
        conn.close()
        return json_response({"error": "Solo se permiten letras en este campo."}, 400)

    if deadline != row["deadline"] and is_past_date(deadline):
        conn.close()
        return json_response(
            {"error": "La fecha de entrega no puede ser anterior al día de hoy."}, 400
        )

    if status not in VALID_STATUSES:
        conn.close()
        return json_response({"error": "Estado inválido."}, 400)

    if status == "terminado":
        completed_at = row["completed_at"] if row["status"] == "terminado" and row["completed_at"] else now_local_str()
    else:
        completed_at = None

    conn.execute(
        "UPDATE vista_compat_tareas SET title=?, description=?, subject=?, professor=?, category=?, type=?, "
        "complexity=?, deadline=?, status=?, collaborators=?, completed_at=? WHERE id=?",
        (
            data.get("title", row["title"]),
            data.get("description", row["description"]),
            data.get("subject", row["subject"]),
            professor,
            data.get("category", row["category"] if "category" in row.keys() else ""),
            data.get("type", row["type"]),
            complexity,
            deadline,
            status,
            collaborators_to_json(collaborators),
            completed_at,
            task_id,
        ),
    )
    if deadline != row["deadline"]:
        upsert_reminder(conn, task_id, user_id, deadline)
    if status == "terminado" or deadline != row["deadline"]:
        conn.execute("DELETE FROM vista_compat_notificaciones WHERE task_id = ? AND type = 'critica'", (task_id,))
    recalc_progress(conn, user_id)
    updated_title = str(data.get("title", row["title"])).strip()
    if row["status"] != "terminado" and status == "terminado":
        add_notification(conn, user_id, "tarea_terminada", "Tarea terminada",
                         f'Marcaste la tarea "{updated_title}" como terminada.', task_id)
    elif row["status"] == "terminado" and status != "terminado":
        add_notification(conn, user_id, "tarea_reabierta", "Tarea reabierta",
                         f'Reabriste la tarea "{updated_title}".', task_id)
    else:
        add_notification(conn, user_id, "tarea_actualizada", "Tarea actualizada",
                         f'Los cambios de la tarea "{updated_title}" se guardaron correctamente.', task_id)
    conn.commit()

    row = fetch_task_with_reminder(conn, task_id)
    conn.close()
    return json_response(serialize_task(row))


@route("DELETE", r"/api/tasks/(?P<task_id>[\w-]+)")
def api_delete_task(req):
    user_id = require_login(req)
    if not user_id:
        return json_response({"error": "No autenticado"}, 401)
    if user_id and get_user_role(user_id) != "estudiante":
        return json_response({"error": "Esta función está reservada para alumnos."}, 403)


    task_id = req.params["task_id"]
    conn = get_db()
    conn.execute("DELETE FROM vista_compat_tareas WHERE id = ? AND user_id = ?", (task_id, user_id))
    recalc_progress(conn, user_id)
    conn.commit()
    conn.close()
    return json_response({"ok": True})


# ===== Etapa 2: roles, habilitación académica documentada y selección docente =====

def require_professor(req):
    user_id = req.current_user_id()
    if not user_id:
        return None, json_response({"error": "No autenticado."}, 401)
    if get_user_role(user_id) != "profesor":
        return None, json_response({"error": "Se requiere el rol Profesor."}, 403)
    return user_id, None


def fecha_utc():
    return datetime.now(timezone.utc).isoformat()


def periodo_actual(conn):
    return conn.execute("SELECT * FROM periodos_academicos WHERE activo=1 "
                        "ORDER BY fecha_inicio DESC LIMIT 1").fetchone()


@route("GET", r"/profesor")
def pagina_profesor(req):
    uid = req.current_user_id()
    if not uid:
        return redirect("/login")
    if get_user_role(uid) != "profesor":
        return redirect(home_path(uid))
    conn = get_db()
    usuario = conn.execute("SELECT name FROM vista_compat_usuarios WHERE id=?", (uid,)).fetchone()
    conn.close()
    return Response(body=render("profesor.html", USER_NAME=escape_html(usuario["name"])))


@route("GET", r"/admin/residencias")
def pagina_configuracion_residencias(req):
    uid = req.current_user_id()
    if not uid:
        return redirect("/login")
    if get_user_role(uid) != "admin":
        return redirect(home_path(uid))
    return Response(body=render("residencias_admin.html"))


@route("GET", r"/api/admin/residencias/contexto")
def api_contexto_academico(req):
    uid, error = require_admin(req)
    if error: return error
    conn = get_db()
    planes = conn.execute("SELECT p.id_plan,c.nombre AS carrera,p.version_plan,p.creditos_totales,p.verificado "
        "FROM planes_estudio p JOIN carreras c ON c.id_carrera=p.id_carrera ORDER BY c.nombre").fetchall()
    alumnos = conn.execute("SELECT id,name,career,control_number FROM vista_compat_usuarios WHERE role='estudiante' "
        "AND active=1 ORDER BY name").fetchall()
    periodos = conn.execute("SELECT * FROM periodos_academicos ORDER BY fecha_inicio DESC").fetchall()
    conn.close()
    return json_response({"planes":[dict(x) for x in planes],"alumnos":[dict(x) for x in alumnos],
                          "periodos":[dict(x) for x in periodos]})


@route("POST", r"/api/admin/residencias/periodos")
def api_crear_periodo(req):
    uid,error=require_admin(req)
    if error:return error
    data=req.json()
    nombre=str(data.get('nombre') or '').strip()
    inicio=str(data.get('fecha_inicio') or '')
    fin=str(data.get('fecha_fin') or '')
    try:
        a=date.fromisoformat(inicio);b=date.fromisoformat(fin)
    except ValueError:
        return json_response({"error":"Fechas de periodo inválidas."},400)
    if not nombre or a>b:
        return json_response({"error":"Revisa el nombre y las fechas del periodo."},400)
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        conn.execute('UPDATE periodos_academicos SET activo=0 WHERE activo=1')
        cur=conn.execute('INSERT INTO periodos_academicos(nombre,fecha_inicio,fecha_fin,activo) VALUES(?,?,?,1)',
                         (nombre,inicio,fin))
        conn.commit(); return json_response({'id_periodo':cur.lastrowid},201)
    except sqlite3.IntegrityError as exc:
        conn.rollback();return json_response({'error':str(exc)},409)
    finally: conn.close()


@route("POST", r"/api/admin/residencias/planes")
def api_verificar_plan(req):
    uid,error=require_admin(req)
    if error:return error
    data=req.json()
    try:
        pid=int(data['id_plan']);total=int(data['creditos_totales'])
    except (KeyError,TypeError,ValueError):
        return json_response({'error':'Plan y créditos totales inválidos.'},400)
    fuente=str(data.get('fuente') or '').strip()
    if total<=0 or len(fuente)<8:
        return json_response({'error':'Debes proporcionar créditos totales y referencia académica verificable.'},400)
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        plan=conn.execute('SELECT id_plan FROM planes_estudio WHERE id_plan=?',(pid,)).fetchone()
        if not plan:
            conn.rollback();return json_response({'error':'Plan no encontrado.'},404)
        if conn.execute("""SELECT 1 FROM asignaciones_residencia ar
            JOIN alumnos a ON a.id_alumno=ar.id_alumno
            WHERE a.id_plan=? AND ar.estado IN ('seleccionada','confirmada') LIMIT 1""",(pid,)).fetchone():
            conn.rollback();return json_response({'error':'No se pueden modificar créditos de un plan con asignaciones activas.'},409)
        conn.execute('UPDATE planes_estudio SET creditos_totales=?, verificado=1 WHERE id_plan=?',(total,pid))
        conn.execute('INSERT OR IGNORE INTO criterios_residencia(id_plan) VALUES(?)',(pid,))
        conn.execute('INSERT INTO auditoria_academica(id_usuario,id_plan,accion,referencia,fecha) VALUES(?,?,?,?,?)',
                     (uid,pid,'verificacion_plan',fuente,fecha_utc()))
        conn.commit();return json_response({'ok':True})
    except sqlite3.IntegrityError as exc:
        conn.rollback();return json_response({'error':str(exc)},409)
    finally:conn.close()


@route("POST", r"/api/admin/residencias/verificaciones")
def api_verificar_alumno(req):
    uid,error=require_admin(req)
    if error:return error
    data=req.json()
    alumno=str(data.get('id_alumno') or '')
    fuente=str(data.get('fuente') or '').strip()
    try:
        pid=int(data['id_periodo']); creditos=int(data['creditos_aprobados'])
    except (KeyError,TypeError,ValueError):
        return json_response({'error':'Periodo o créditos inválidos.'},400)
    if creditos<0 or len(fuente)<8 or not all(isinstance(data.get(k),bool) for k in
                         ('servicio_social','actividades_complementarias','sin_curso_especial')):
        return json_response({'error':'Se requieren créditos, tres verificaciones y una referencia académica.'},400)
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        alumno_info=conn.execute('''SELECT p.creditos_totales,p.verificado FROM alumnos a
          JOIN planes_estudio p ON p.id_plan=a.id_plan JOIN usuarios u ON u.id_usuario=a.id_alumno
          WHERE a.id_alumno=? AND u.activo=1''',(alumno,)).fetchone()
        if not alumno_info or not alumno_info['verificado'] or creditos>alumno_info['creditos_totales']:
            conn.rollback();return json_response({'error':'Plan sin validar, alumno inexistente o créditos excesivos.'},400)
        periodo=conn.execute('SELECT 1 FROM periodos_academicos WHERE id_periodo=? AND activo=1',(pid,)).fetchone()
        if not periodo:
            conn.rollback();return json_response({'error':'Periodo no activo.'},400)
        existente=conn.execute('SELECT id_verificacion FROM verificaciones_residencia WHERE id_alumno=? AND id_periodo=?',
                               (alumno,pid)).fetchone()
        if existente and conn.execute('SELECT 1 FROM asignaciones_residencia WHERE id_verificacion=? AND estado IN (\'seleccionada\',\'confirmada\')',
                                     (existente['id_verificacion'],)).fetchone():
            conn.rollback();return json_response({'error':'No se puede modificar una verificación con asignación activa.'},409)
        vid=existente['id_verificacion'] if existente else str(uuid.uuid4())
        valores=(creditos,int(data['servicio_social']),int(data['actividades_complementarias']),
                 int(data['sin_curso_especial']),'verificada',uid,fuente,fecha_utc())
        if existente:
            conn.execute('''UPDATE verificaciones_residencia SET creditos_aprobados=?, servicio_social=?,
             actividades_complementarias=?,sin_curso_especial=?,estado=?,id_usuario_verificador=?,fuente_verificacion=?,
             fecha_verificacion=? WHERE id_verificacion=?''',(*valores,vid))
        else:
            conn.execute('''INSERT INTO verificaciones_residencia(id_verificacion,id_alumno,id_periodo,creditos_aprobados,
            servicio_social,actividades_complementarias,sin_curso_especial,estado,id_usuario_verificador,
            fuente_verificacion,fecha_verificacion) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(vid,alumno,pid,*valores))
        habilitado=conn.execute('SELECT habilitado FROM vista_elegibilidad_residencia WHERE id_verificacion=?',(vid,)).fetchone()['habilitado']
        conn.commit();return json_response({'ok':True,'habilitado':bool(habilitado)})
    except sqlite3.IntegrityError as exc:
        conn.rollback();return json_response({'error':str(exc)},409)
    finally:conn.close()


@route("GET", r"/api/profesor/residencias")
def api_profesor_residencias(req):
    uid,error=require_professor(req)
    if error:return error
    conn=get_db()
    periodo=periodo_actual(conn)
    if not periodo:
        conn.close();return json_response({'periodo':None,'elegibles':[],'asignaciones':[],'cupo':3})
    pid=periodo['id_periodo']
    asignaciones=conn.execute('''SELECT ar.id_asignacion,ar.estado, ar.id_alumno,
     trim(u.nombres||' '||coalesce(u.apellido_paterno,'')||' '||coalesce(u.apellido_materno,'')) AS alumno,
     a.numero_control FROM asignaciones_residencia ar JOIN usuarios u ON u.id_usuario=ar.id_alumno
     JOIN alumnos a ON a.id_alumno=ar.id_alumno WHERE ar.id_profesor=? AND ar.id_periodo=?
     AND ar.estado IN ('seleccionada','confirmada') ORDER BY ar.fecha_seleccion''',(uid,pid)).fetchall()
    elegibles=conn.execute('''SELECT e.id_alumno,u.nombres||' '||coalesce(u.apellido_paterno,'')||' '||coalesce(u.apellido_materno,'') AS alumno,
       a.numero_control,c.nombre AS carrera,e.porcentaje_creditos
       FROM vista_elegibilidad_residencia e JOIN usuarios u ON u.id_usuario=e.id_alumno
       JOIN alumnos a ON a.id_alumno=e.id_alumno
       JOIN planes_estudio p ON p.id_plan=a.id_plan JOIN carreras c ON c.id_carrera=p.id_carrera
       WHERE e.id_periodo=? AND e.habilitado=1 AND u.activo=1
       AND NOT EXISTS(SELECT 1 FROM asignaciones_residencia ar
        WHERE ar.id_alumno=e.id_alumno AND ar.id_periodo=? AND ar.estado IN ('seleccionada','confirmada'))
       ORDER BY alumno LIMIT 100''',(pid,pid)).fetchall()
    conn.close()
    return json_response({'periodo':dict(periodo),'elegibles':[dict(x) for x in elegibles],
         'asignaciones':[dict(x) for x in asignaciones],'cupo':3})


@route("POST",r"/api/profesor/residencias/seleccionar")
def api_profesor_seleccionar(req):
    uid,error=require_professor(req)
    if error:return error
    data=req.json(); alumno=str(data.get('id_alumno') or '')
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        periodo=periodo_actual(conn)
        if not periodo:
            conn.rollback();return json_response({'error':'No existe periodo académico activo.'},400)
        pid=periodo['id_periodo']
        v=conn.execute('SELECT id_verificacion FROM vista_elegibilidad_residencia WHERE id_alumno=? AND id_periodo=? AND habilitado=1',
                       (alumno,pid)).fetchone()
        if not v:
            conn.rollback();return json_response({'error':'El alumno no cuenta con verificación académica suficiente.'},403)
        aid=str(uuid.uuid4())
        conn.execute('''INSERT INTO asignaciones_residencia(id_asignacion,id_alumno,id_profesor,id_periodo,id_verificacion,
              estado,fecha_seleccion) VALUES (?,?,?,?,?,'seleccionada',?)''',(aid,alumno,uid,pid,v['id_verificacion'],fecha_utc()))
        conn.execute('''INSERT INTO historial_asignaciones(id_historial,id_asignacion,id_usuario_actor,accion,fecha)
           VALUES (?,?,?,?,?)''',(str(uuid.uuid4()),aid,uid,'seleccionada',fecha_utc()))
        conn.commit();return json_response({'id_asignacion':aid,'estado':'seleccionada'},201)
    except sqlite3.IntegrityError as exc:
        conn.rollback();return json_response({'error':str(exc)},409)
    finally:conn.close()


@route("POST",r"/api/profesor/residencias/confirmar")
def api_profesor_confirmar(req):
    uid,error=require_professor(req)
    if error:return error
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        periodo=periodo_actual(conn)
        if not periodo:
            conn.rollback();return json_response({'error':'No hay periodo activo.'},400)
        rows=conn.execute('''SELECT id_asignacion,id_alumno FROM asignaciones_residencia WHERE id_profesor=? AND id_periodo=?
            AND estado='seleccionada' ORDER BY fecha_seleccion''',(uid,periodo['id_periodo'])).fetchall()
        if not rows:
            conn.rollback();return json_response({'error':'No hay alumnos pendientes de confirmar.'},400)
        if len(rows)>3:
            conn.rollback();return json_response({'error':'Se excedió el cupo de tres.'},409)
        for r in rows:
            now=fecha_utc()
            conn.execute("UPDATE asignaciones_residencia SET estado='confirmada',fecha_confirmacion=? WHERE id_asignacion=?",
                         (now,r['id_asignacion']))
            conn.execute('''INSERT INTO historial_asignaciones(id_historial,id_asignacion,id_usuario_actor,accion,fecha)
               VALUES (?,?,?,?,?)''',(str(uuid.uuid4()),r['id_asignacion'],uid,'confirmada',now))
            # El disparador SQL `notificar_confirmacion_actualizada` crea exactamente
            # un aviso por asignación. No duplicar aquí la notificación desde Python.
        conn.commit();return json_response({'confirmados':len(rows)})
    except sqlite3.IntegrityError as exc:
        conn.rollback();return json_response({'error':str(exc)},409)
    finally:conn.close()


@route("DELETE",r"/api/profesor/residencias/selecciones/(?P<id_asignacion>[\w-]+)")
def api_profesor_cancelar_seleccion(req):
    uid,error=require_professor(req)
    if error:return error
    aid=req.params['id_asignacion']
    conn=get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        row=conn.execute('SELECT estado FROM asignaciones_residencia WHERE id_asignacion=? AND id_profesor=?',(aid,uid)).fetchone()
        if not row:
            conn.rollback();return json_response({'error':'Selección inexistente.'},404)
        if row['estado']!='seleccionada':
            conn.rollback();return json_response({'error':'Una asignación confirmada no se puede retirar desde este panel.'},409)
        conn.execute("UPDATE asignaciones_residencia SET estado='cancelada' WHERE id_asignacion=?",(aid,))
        conn.execute('''INSERT INTO historial_asignaciones(id_historial,id_asignacion,id_usuario_actor,accion,fecha)
          VALUES(?,?,?,?,?)''',(str(uuid.uuid4()),aid,uid,'cancelada',fecha_utc()))
        conn.commit();return json_response({'ok':True})
    finally:conn.close()


@route("GET",r"/api/alumno/residencia")
def api_alumno_residencia(req):
    uid=req.current_user_id()
    if not uid:return json_response({'error':'No autenticado.'},401)
    if get_user_role(uid)!='estudiante':return json_response({'error':'Solo alumnos.'},403)
    conn=get_db();periodo=periodo_actual(conn)
    if not periodo:
        conn.close();return json_response({'periodo':None,'habilitado':False,'asignacion':None})
    v=conn.execute('''SELECT ve.porcentaje_creditos,ve.habilitado,vr.estado AS estado_verificacion
         FROM vista_elegibilidad_residencia ve JOIN verificaciones_residencia vr
         ON vr.id_verificacion=ve.id_verificacion
         WHERE ve.id_alumno=? AND ve.id_periodo=?''', (uid,periodo['id_periodo'])).fetchone()
    asignacion=conn.execute('''SELECT ar.estado, p.nombres||' '||coalesce(p.apellido_paterno,'') AS profesor,ar.fecha_confirmacion
       FROM asignaciones_residencia ar JOIN usuarios p ON p.id_usuario=ar.id_profesor
       WHERE ar.id_alumno=? AND ar.id_periodo=? AND ar.estado='confirmada' LIMIT 1''',
       (uid,periodo['id_periodo'])).fetchone()
    conn.close()
    return json_response({'periodo':dict(periodo),'habilitado':bool(v and v['habilitado']),
          'porcentaje_creditos':v['porcentaje_creditos'] if (v and v['estado_verificacion']=='verificada') else None,
          'estado_verificacion':v['estado_verificacion'] if v else 'pendiente',
          'asignacion':dict(asignacion) if asignacion else None})


class SpoteHandler(BaseHTTPRequestHandler):
    server_version = "SpoteHTTP/1.0"

    def log_message(self, fmt, *args):
        print(f'[{self.log_date_time_string()}] {self.address_string()} - {fmt % args}')

    def _dispatch(self, method, head_only=False):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if method == "GET" and path.startswith("/static/"):
            return self._serve_static(path, head_only=head_only)

        for route_method, regex, func in ROUTES:
            if route_method != method:
                continue
            match = regex.match(path)
            if match:
                req = Request(self, method, path, query, match.groupdict())
                try:
                    with DB_LOCK:
                        resp = func(req)
                except Exception:
                    traceback.print_exc()
                    resp = json_response(
                        {"error": "Ocurrió un error interno en el servidor. Revisa la consola donde corre app.py."},
                        500,
                    )
                return self._send(resp, head_only=head_only)

        self._send(Response(status=404, body="<h1>404 - No encontrado</h1>"), head_only=head_only)

    def _serve_static(self, path, head_only=False):
        rel_path = path[len("/static/"):]
        full_path = os.path.normpath(os.path.join(STATIC_DIR, rel_path))
        if not full_path.startswith(STATIC_DIR) or not os.path.isfile(full_path):
            self._send(Response(status=404, body="Not found"), head_only=head_only)
            return
        content_type, _ = mimetypes.guess_type(full_path)
        with open(full_path, "rb") as f:
            body = f.read()
        self._send(
            Response(
                body=body,
                headers={
                    "Content-Type": content_type or "application/octet-stream",
                    "Cache-Control": "no-store, no-cache, must-revalidate",
                },
            ),
            head_only=head_only,
        )

    def _send(self, resp, head_only=False):
        self.send_response(resp.status)
        resp.headers.setdefault("Cache-Control", "no-store, no-cache, must-revalidate")
        for key, value in resp.headers.items():
            self.send_header(key, value)
        for cookie in resp.cookies_to_set:
            self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Length", str(len(resp.body)))
        self.end_headers()
        if not head_only:
            self.wfile.write(resp.body)

    def do_GET(self):
        self._dispatch("GET")

    def do_HEAD(self):
        self._dispatch("GET", head_only=True)

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")


def main():
    init_db()
    if len(sys.argv) > 1 and sys.argv[1] == "--crear-admin":
        create_admin_cli()
        return
    server = ThreadingHTTPServer(("0.0.0.0", PORT), SpoteHandler)
    print("=" * 60)
    print("  SPOTE corriendo en http://localhost:%d" % PORT)
    print("  Las cuentas se migran de la base anterior o las crea un administrador autorizado.")
    print("  Administrador: python3 app.py --crear-admin")
    print("  Presiona Ctrl+C para detener el servidor")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")


if __name__ == "__main__":
    main()

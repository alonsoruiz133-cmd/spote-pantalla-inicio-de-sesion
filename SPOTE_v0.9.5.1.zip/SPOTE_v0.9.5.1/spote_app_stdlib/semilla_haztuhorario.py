"""Subconjunto verificable de páginas públicas; actualización total mediante haztuhorario_catalogo.py.
No se atribuyen departamentos ni números de empleado.
"""
import hashlib
from haztuhorario_catalogo import guardar
SISTEMAS = {
  'CÁLCULO DIFERENCIAL':['Allen Epifanio Lopez','Cerda Leon Erwin Rommel','Cordova Ventura Kevin Alberto','Flores Villa Miguel Angel','Juarez Martinez Rodrigo','Olmedo Landeros Irma Karina','Velazquez Rodriguez Liliana','Veronica Martinez Villafuerte','Zavala Aguillon Brenda'],
  'FUNDAMENTOS DE PROGRAMACIÓN':['Alfredo Salazar Garcia','Araceli Campos Ortiz','CARREON VALERIO AIDE NATZIELLY','Karina Cabrera Chagoyan','Marcelino Vargas Lopez','MELIDA HERNANDEZ CARMEN','Muniz Jimenez Araceli Estefania','Rocio Cipactli Sanchez Montes','Sandra Marisol Torres Oyervides'],
  'REDES DE COMPUTADORAS':['Omar Sanchez Jacome','Sergio Arturo Mendoza Morales','Valdivia Lugo Eduardo'],
  'PROGRAMACIÓN WEB':['David Andres Valdes Martinez','Sandoval Nunez Juan Manuel'],
  'SISTEMAS PROGRAMABLES':['Jose Luis Gaytan Malacara','MONA PENA LUIS JAVIER'],
  'INTELIGENCIA ARTIFICIAL':['CASTANUELA FUENTES LUIS ENRIQUE','Ernesto Linan Garcia'],
}
GESTION={
  'Cálculo Diferencial':['Ana Victoria Ferniza Sandoval','Cerda Leon Erwin Rommel','Cordova Ventura Kevin Alberto','Edna Marina Gonzalez Martinez','Eliana Sarahi Sanchez Gonzalez','Flores Villa Miguel Angel','Olmedo Landeros Irma Karina'],
  'Contabilidad Orientada a los Negocios':['Agustin Antonio Galindo Siller','Cristina Vanessa Juarez Hernandez','De Leon Covarubias Ana Laura','Jesus Alberto Picazo Rada','Liliana Lopez Camacho','Sergio De Leon Pescina'],
}
INDUSTRIAL={
  'DIBUJO INDUSTRIAL':['Alejandro Ayala Ramos','IBARRA TREVINO JUAN','Isidro Gustavo De La Pena Flores','Monica Hernandez Garcia','Rene Sanchez Ramos'],
  'INVESTIGACIÓN DE OPERACIONES I':['Eduardo Marroquin Espinoza','Javier Galindres Coto','Rosa Maria Monsivais Carrillo','Yadira Iracema Reyes Carlos'],
}

def inicializar_semilla(conn):
 if conn.execute('SELECT COUNT(*) FROM catalogo_haz_docentes').fetchone()[0]:return
 resultado={}
 for carrera,datos,url in (
  ('Sistemas',SISTEMAS,'https://haztuhorario.com/recomendaciones/37076-sistemas'),
  ('Gestión Empresarial',GESTION,'https://haztuhorario.com/recomendaciones/37121-gestion-empresarial'),
  ('Industrial',INDUSTRIAL,'https://haztuhorario.com/recomendaciones/37203-industrial')):
  items=[]
  for materia,nombres in datos.items():
   for nombre in nombres:
    identificador='muestra-'+hashlib.sha256(nombre.casefold().encode()).hexdigest()[:16]
    items.append((identificador,nombre,materia,'Semestre no identificado en muestra'))
  resultado[carrera]=(url,items)
 guardar(conn,resultado)

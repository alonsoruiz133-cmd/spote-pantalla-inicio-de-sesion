"""Importación de fichas PÚBLICAS de Haztuhorario; no crea cuentas ni deduce departamentos."""
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.parse import urlparse
import re
import unicodedata

FUENTES = {
 'Sistemas': 'https://haztuhorario.com/recomendaciones/37076-sistemas',
 'Mecatrónica': 'https://haztuhorario.com/recomendaciones/37169-mecatronica',
 'Mecánica': 'https://haztuhorario.com/recomendaciones/37238-mecanica',
 'Industrial': 'https://haztuhorario.com/recomendaciones/37203-industrial',
 'Eléctrica': 'https://haztuhorario.com/recomendaciones/37145-electrica',
 'Electrónica': 'https://haztuhorario.com/recomendaciones/37133-electronica',
 'Gestión Empresarial': 'https://haztuhorario.com/recomendaciones/37121-gestion-empresarial',
 'Materiales': 'https://haztuhorario.com/recomendaciones/37157-materiales',
}

# Obtiene IDs y rutas desde la página de recomendaciones cuando se actualiza.
INDICE='https://haztuhorario.com/recomendaciones'

class Extraer(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.tag=None;self.enlace='';self.titulo='';self.semestre='';self.result=[];self.nivel=0;self.bufer='';self.indice=[]
 def handle_starttag(self,tag,attrs):
  att=dict(attrs)
  if tag in ('h2','h3'):
   self.tag=tag;self.bufer=''
  if tag=='a':
   self.enlace=att.get('href','');self.bufer='';self.tag='a'
 def handle_data(self,data):
  if self.tag:self.bufer+=data
 def handle_endtag(self,tag):
  if tag!=self.tag:return
  txt=' '.join(self.bufer.split())
  if tag=='h2' and txt.lower().startswith('semestre'):
   self.semestre=txt
  elif tag=='h3':self.titulo=txt
  elif tag=='a':
   if '/profesores/' in self.enlace and self.titulo and txt:
    txt=txt.lstrip('→').strip()
    if txt.casefold() not in ('docente sin asignar','sin asignar','por asignar'):
     match=re.search(r'/profesores/(\d+)', self.enlace)
     if match:self.result.append((match.group(1),txt,self.titulo,self.semestre))
   elif '/recomendaciones/' in self.enlace and txt:self.indice.append((txt,self.enlace))
  self.tag=None;self.bufer=''

def descargar(url):
 req=Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; SPOTE-docentes/0.9; uso educativo)', 'Accept':'text/html'})
 with urlopen(req,timeout=20) as r:
  if urlparse(r.url).hostname not in ('haztuhorario.com','www.haztuhorario.com'):raise ValueError('Redirección a dominio no autorizado')
  html=r.read(4_000_000).decode('utf-8','replace')
 if '<html' not in html.lower():raise ValueError('La respuesta no es HTML')
 return html

def recopilar():
 indice=Extraer()
 try:indice.feed(descargar(INDICE))
 except Exception:pass  # Las URLs conocidas siguen siendo utilizables.
 urls=dict(FUENTES)
 for nombre,href in indice.indice:
  if nombre.strip() in urls and re.match(r'^/recomendaciones/\d+[-\w]*$',href):
   urls[nombre]='https://haztuhorario.com'+href
 # Se conserva lo previamente importado si hay errores de conexión.
 resultado={}; fallos={}
 for carrera,url in urls.items():
  try:
   parser=Extraer();parser.feed(descargar(url))
   if len(parser.result)<3:raise ValueError('Página sin catálogo reconocible; se preserva la información anterior')
   resultado[carrera]=(url,parser.result)
  except Exception as exc:fallos[carrera]=str(exc)
 return resultado,fallos

def crear_tablas(conn):
 conn.executescript('''
 CREATE TABLE IF NOT EXISTS catalogo_haz_docentes (
   id_haz TEXT PRIMARY KEY, nombre TEXT NOT NULL, fuente TEXT NOT NULL,
   ultima_actualizacion TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS catalogo_haz_oferta (
   id_haz TEXT NOT NULL REFERENCES catalogo_haz_docentes(id_haz),
   carrera TEXT NOT NULL, materia TEXT NOT NULL, semestre TEXT NOT NULL,
   pagina_fuente TEXT NOT NULL, PRIMARY KEY(id_haz,carrera,materia,semestre));
 CREATE INDEX IF NOT EXISTS idx_haz_oferta_carrera ON catalogo_haz_oferta(carrera);
 ''')

def guardar(conn,resultado):
 from datetime import datetime,timezone
 crear_tablas(conn)
 fecha=datetime.now(timezone.utc).isoformat()
 for carrera,(url,lista) in resultado.items():
  # Una importación válida sustituye solamente la oferta de esa carrera.
  conn.execute('DELETE FROM catalogo_haz_oferta WHERE carrera=?',(carrera,))
  for ident,nombre,materia,semestre in lista:
   conn.execute('''INSERT INTO catalogo_haz_docentes(id_haz,nombre,fuente,ultima_actualizacion)
      VALUES(?,?,?,?) ON CONFLICT(id_haz) DO UPDATE SET nombre=excluded.nombre,ultima_actualizacion=excluded.ultima_actualizacion''',
      (ident,nombre,'Haztuhorario',fecha))
   conn.execute('INSERT OR IGNORE INTO catalogo_haz_oferta VALUES(?,?,?,?,?)',(ident,carrera,materia,semestre,url))
 demo_existe=conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='profesores_demo_haz'").fetchone()
 if demo_existe:
  conn.execute('''DELETE FROM catalogo_haz_docentes WHERE id_haz NOT IN (SELECT id_haz FROM catalogo_haz_oferta)
           AND id_haz NOT IN (SELECT id_haz FROM profesores_demo_haz)''')
 else:
  conn.execute('DELETE FROM catalogo_haz_docentes WHERE id_haz NOT IN (SELECT id_haz FROM catalogo_haz_oferta)')
 return conn.execute('SELECT COUNT(*) FROM catalogo_haz_docentes').fetchone()[0]

if __name__=='__main__':
 import sqlite3,os
 ruta=os.environ.get('SPOTE_DB_PATH',os.path.join(os.path.dirname(__file__),'spote_normalizada.db'))
 conn=sqlite3.connect(ruta);conn.execute('PRAGMA foreign_keys=ON')
 data,errors=recopilar()
 if data:
  with conn:n=guardar(conn,data)
  print(f'Catálogo actualizado: {n} docentes únicos de {len(data)} carreras.')
 else:print('No se importó nada; comprueba Internet. El catálogo previo no se modificó.')
 for carrera,error in errors.items():print(f'{carrera}: {error}')
 conn.close()

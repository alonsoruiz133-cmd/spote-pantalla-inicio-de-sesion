"""Genera exclusivamente datos FICTICIOS para una base de DEMOSTRACIÓN de SPOTE.

Uso interno de preparación; no se ejecuta al iniciar la aplicación. NO ejecutar
contra una base real: usa una copia limpia y hace comprobaciones antes de insertar.
"""
import sqlite3
import uuid
import threading
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path
import app
from probar_etapa2 import Cliente

CLAVE = 'SpoteDemo2026!'
ADMIN = 'admin@spote.mx'
PROFESOR = 'profesor.demo@spote.example'
PERIODO = 'DEMOSTRACIÓN · Enero-Junio 2027'
TOTAL = 260  # Valor ficticio de ejemplo; NO equivale a créditos del plan oficial
FUENTE = 'SIMULACION ACADEMICA - DATOS FICTICIOS, NO OFICIALES'
ALUMNOS = [
    # Nombre, paterno, materno, control, teléfono, créditos, servicio social, complementarias, sin curso especial, verificado
    ('Ana', 'Garcia', 'Lopez', 'C90000001', '8110000001', 250, True, True, True, True),
    ('Luis', 'Hernandez', 'Perez', 'C90000002', '8110000002', 208, True, True, True, True),
    ('Sofia', 'Martinez', 'Ruiz', 'C90000003', '8110000003', 209, True, True, True, True),
    ('Diego', 'Torres', 'Nunez', 'C90000004', '8110000004', 230, True, True, True, True),
    ('Valeria', 'Soto', 'Diaz', 'C90000005', '8110000005', 207, True, True, True, True),
    ('Carlos', 'Luna', 'Ramos', 'C90000006', '8110000006', 240, False, True, True, True),
    ('Elena', 'Flores', 'Mora', 'C90000007', '8110000007', None, None, None, None, False),
]

def crear():
    ruta = Path(app.DB_PATH)
    app.init_db()
    c=app.get_db()
    try:
        if c.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]:
            raise RuntimeError('La base contiene usuarios: se cancela para no modificar datos existentes.')
        app.upsert_admin(c, ADMIN, 'jard2341', 'Administrador')
    finally:
        c.close()
    servidor=ThreadingHTTPServer(('127.0.0.1',0),app.SpoteHandler)
    hilo=threading.Thread(target=servidor.serve_forever,daemon=True)
    hilo.start()
    try:
        cl=Cliente(servidor.server_address[1]);cl.login(ADMIN, 'jard2341')
        cl.json('POST','/api/admin/users',{
            'role':'profesor','first_name':'Patricia','last_name_p':'Morales','last_name_m':'Rios',
            'career':'','semester':'','control_number':'','phone':'',
            'email':PROFESOR,'password':CLAVE},201)
        p=cl.json('POST','/api/admin/residencias/periodos',{
            'nombre':PERIODO,'fecha_inicio':'2027-01-12','fecha_fin':'2027-06-25'},201)['id_periodo']
        contexto=cl.json('GET','/api/admin/residencias/contexto')
        id_profesor=next(x['id_profesor'] for x in contexto['profesores'] if x['nombre'].startswith('Patricia'))
        id_carrera=next(x['id_carrera'] for x in contexto['carreras'] if x['nombre']=='Ingeniería en Sistemas Computacionales')
        cl.json('POST','/api/admin/residencias/profesores/carrera',{'id_profesor':id_profesor,'id_carrera':id_carrera})
        planes=contexto['planes']
        plan=next(x['id_plan'] for x in planes if x['carrera']=='Ingeniería en Sistemas Computacionales')
        cl.json('POST','/api/admin/residencias/planes',{
            'id_plan':plan,'creditos_totales':TOTAL,'fuente':FUENTE})
        for nombre,paterno,materno,control,telefono,creditos,ss,comp,esp,verificado in ALUMNOS:
            uid=cl.json('POST','/api/admin/users',{
                'role':'estudiante','first_name':nombre,'last_name_p':paterno,'last_name_m':materno,
                'career':'Ingeniería en Sistemas Computacionales','semester':'10',
                'control_number':control,'phone':telefono,
                'email':control[1:].lower()+'@saltillo.tecnm.mx','password':CLAVE},201)['id']
            if verificado:
                res=cl.json('POST','/api/admin/residencias/verificaciones',{
                    'id_alumno':uid,'id_periodo':p,'creditos_aprobados':creditos,
                    'servicio_social':ss,'actividades_complementarias':comp,
                    'sin_curso_especial':esp,'fuente':FUENTE})
                expected=creditos>=208 and ss and comp and esp
                assert res['habilitado']==expected,(nombre,res)
    finally:
        servidor.shutdown();servidor.server_close();hilo.join(timeout=5)
    # Quitar las sesiones generadas durante la carga y los avisos administrativos
    # del proceso de preparación para que el usuario pruebe desde cero.
    c=app.get_db()
    try:
        c.execute('DELETE FROM sesiones')
        c.execute('DELETE FROM notificaciones')
        c.commit()
        assert c.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]==9
        assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not c.execute('PRAGMA foreign_key_check').fetchall()
        assert c.execute('SELECT COUNT(*) FROM vista_elegibilidad_residencia WHERE habilitado=1').fetchone()[0]==4
        assert c.execute('SELECT COUNT(*) FROM asignaciones_residencia').fetchone()[0]==0
        print('Escenario creado: 1 administrador + 1 profesor + 7 alumnos')
        print('4 elegibles, 1 con créditos insuficientes, 1 sin servicio social, 1 pendiente de verificación')
        print('Sin asignaciones iniciales: permite probar la selección y confirmación real.')
    finally:
        c.close()

if __name__=='__main__':
    crear()

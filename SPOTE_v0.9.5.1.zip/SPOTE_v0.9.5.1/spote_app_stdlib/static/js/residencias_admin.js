'use strict';
const el=(id)=>document.getElementById(id);
function aviso(t,err=false){const x=el('academicoAviso');x.textContent=t;x.className=err?'flash flash-error':'flash flash-success';x.style.display='block';}
async function peticion(url,opts={}){
 const r=await fetch(url,{headers:{'Content-Type':'application/json'},credentials:'same-origin',...opts});
 if(r.status===401){location.href='/login';throw Error('Sesión finalizada');}
 const data=await r.json();if(!r.ok)throw Error(data.error||'Error del servidor');return data;
}
function opciones(id,list,valor,etiqueta){
 const x=el(id);x.replaceChildren();const inicio=document.createElement('option');inicio.value='';inicio.textContent='Seleccionar...';x.appendChild(inicio);
 for(const i of list){const o=document.createElement('option');o.value=String(valor(i));o.textContent=etiqueta(i);x.appendChild(o);}
}
let contextoResidencias=null;
async function recargar(){const r=await peticion('/api/admin/residencias/contexto');
 contextoResidencias=r;
 opciones('profesorId',r.profesores,x=>x.id_profesor,x=>`${x.nombre} · ${x.carrera||'Carrera sin configurar'}`);
 opciones('profesorCarrera',r.carreras,x=>x.id_carrera,x=>x.nombre);
 opciones('planId',r.planes,x=>x.id_plan,x=>`${x.carrera} (${x.version_plan}) · ${x.creditos_totales??'Sin créditos'} ${x.verificado?'✓':''}`);
 opciones('verAlumno',r.alumnos,x=>x.id,x=>`${x.name} · ${x.control_number||'sin control'} · ${x.career||''}`);
 opciones('verPeriodo',r.periodos.filter(x=>x.activo),x=>x.id_periodo,x=>x.nombre);
 mostrarCalculos();
}
function mostrarCalculos(){
 if(!contextoResidencias)return;
 const p=contextoResidencias.planes.find(x=>String(x.id_plan)===el('planId').value);
 const totalPlan=Number(el('planCreditos').value)||Number(p?.creditos_totales)||0;
 el('planCalculo').textContent=totalPlan>0?`Con un mínimo de 80%, se requieren ${Math.ceil(totalPlan*.8)} de ${totalPlan} créditos (referencia orientativa; se aplican los criterios guardados del plan).`:'Introduce los créditos totales de un plan para calcular el mínimo.';
 const alumno=contextoResidencias.alumnos.find(x=>String(x.id)===el('verAlumno').value);
 const plan=contextoResidencias.planes.find(x=>x.carrera===alumno?.career);
 const total=Number(plan?.creditos_totales)||0;
 const n=el('verCreditos').value.trim();
 if(!alumno||!total||!n){el('alumnoCalculo').textContent='Selecciona un alumno con plan verificado e introduce créditos aprobados.';return;}
 const creditos=Number(n);
 if(!Number.isInteger(creditos)||creditos<0||creditos>total){el('alumnoCalculo').textContent='Los créditos deben ser un número entero entre 0 y '+total+'.';return;}
 const porcentaje=100*creditos/total;
 const requisitos=el('verSocial').checked&&el('verComplementarias').checked&&el('verSinEspecial').checked;
 el('alumnoCalculo').textContent=`Avance: ${porcentaje.toFixed(1)}% (${creditos}/${total}). ${porcentaje>=80&&requisitos?'Cumple las condiciones mostradas, sujeto a verificación documental.':'Aún faltan créditos o requisitos.'}`;
}
function conectar(form,url,datos,mensaje){el(form).addEventListener('submit',async(ev)=>{
 ev.preventDefault();try{const respuesta=await peticion(url,{method:'POST',body:JSON.stringify(datos())});
 aviso(mensaje+(Object.hasOwn(respuesta,'habilitado')?respuesta.habilitado?' Alumno habilitado.':' El alumno todavía no cumple todos los requisitos.':''));await recargar();
 }catch(e){aviso(e.message,true);}
});}
document.addEventListener('DOMContentLoaded',()=>{
 conectar('profesorCarreraForm','/api/admin/residencias/profesores/carrera',()=>({id_profesor:el('profesorId').value,id_carrera:el('profesorCarrera').value}),'Carrera del profesor guardada.');
 conectar('periodoForm','/api/admin/residencias/periodos',()=>({nombre:el('periodoNombre').value,fecha_inicio:el('periodoInicio').value,fecha_fin:el('periodoFin').value}),'Periodo creado.');
 conectar('planForm','/api/admin/residencias/planes',()=>({id_plan:el('planId').value,creditos_totales:el('planCreditos').value,fuente:el('planFuente').value}),'Plan verificado.');
 conectar('verificacionForm','/api/admin/residencias/verificaciones',()=>({id_alumno:el('verAlumno').value,id_periodo:el('verPeriodo').value,creditos_aprobados:el('verCreditos').value,
   servicio_social:el('verSocial').checked,actividades_complementarias:el('verComplementarias').checked,sin_curso_especial:el('verSinEspecial').checked,fuente:el('verFuente').value}),'Verificación registrada.');
 ['planId','planCreditos','verAlumno','verCreditos','verSocial','verComplementarias','verSinEspecial'].forEach(id=>{el(id).addEventListener('input',mostrarCalculos);el(id).addEventListener('change',mostrarCalculos);});
 el('profesorId').addEventListener('change',()=>{const x=contextoResidencias?.profesores.find(v=>v.id_profesor===el('profesorId').value);el('profesorCarrera').value=x?.id_carrera?String(x.id_carrera):'';});
 recargar().catch(e=>aviso(e.message,true));
});

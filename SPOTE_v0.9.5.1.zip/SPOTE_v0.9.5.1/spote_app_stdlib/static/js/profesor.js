'use strict';
let estadoResidencias = null;
const nodo = (id) => document.getElementById(id);

function aviso(texto, error=false) {
  const el = nodo('residenciaAviso');
  el.textContent = texto;
  el.className = error ? 'flash flash-error' : 'flash flash-success';
  el.style.display = 'block';
}
async function solicitar(url, opciones={}) {
  const respuesta=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opciones});
  if (respuesta.status===401) { location.href='/login'; throw new Error('Sesión vencida'); }
  const datos=await respuesta.json();
  if (!respuesta.ok) throw new Error(datos.error || 'Error de comunicación con el servidor.');
  return datos;
}
function elemento(tag, clase, texto) {
  const x=document.createElement(tag);
  if (clase) x.className=clase;
  if (texto!==undefined) x.textContent=texto;
  return x;
}
function mostrarLista(id,filas,vacia,creador) {
  const root=nodo(id); root.replaceChildren();
  if (!filas.length) root.appendChild(elemento('p','caption',vacia));
  for (const fila of filas) root.appendChild(creador(fila));
}
function representar() {
  if (!estadoResidencias) return;
  const s=estadoResidencias,as=s.asignaciones || [], elegibles=s.elegibles || [];
  nodo('asesoradosActuales').textContent=`${as.length}/3`;
  nodo('residenciaPeriodo').textContent=s.periodo?.nombre || 'Sin periodo';
  nodo('elegiblesNumero').textContent=String(elegibles.length);
  nodo('confirmarAsesorados').disabled=!s.periodo || !as.some(x=>x.estado==='seleccionada');
  mostrarLista('asesoradosLista',as,'No has seleccionado alumnos para este periodo.',(a)=>{
    const card=elemento('div','residencia-alumno');
    const info=elemento('div','');
    info.appendChild(elemento('strong','',a.alumno));
    info.appendChild(elemento('div','caption',`${a.numero_control || 'Sin número de control'} · ${a.estado==='confirmada'?'Confirmado':'Sin confirmar'}`));
    card.appendChild(info);
    if(a.estado==='seleccionada'){
      const b=elemento('button','btn btn-outline btn-small','Retirar');b.type='button';
      b.onclick=()=>accion(`/api/profesor/residencias/selecciones/${encodeURIComponent(a.id_asignacion)}`,{method:'DELETE'},'Selección retirada.');
      card.appendChild(b);
    } else card.appendChild(elemento('span','badge badge-active','Confirmado'));
    return card;
  });
  const busqueda=nodo('buscarCandidato').value.toLocaleLowerCase('es');
  const visibles=elegibles.filter(x=>`${x.alumno} ${x.numero_control}`.toLocaleLowerCase('es').includes(busqueda));
  mostrarLista('candidatosLista',visibles,!s.carrera_configurada?'Un administrador debe registrar primero tu carrera.':s.periodo?'No hay alumnos habilitados de tu misma carrera.':'Primero debe configurarse un periodo académico.',(a)=>{
    const card=elemento('div','residencia-alumno');
    const info=elemento('div',''); info.appendChild(elemento('strong','',a.alumno));
    info.appendChild(elemento('div','caption',`${a.numero_control || ''} · ${a.carrera} · ${a.porcentaje_creditos}%`));
    card.appendChild(info);
    const b=elemento('button','btn btn-primary btn-small','Seleccionar');b.type='button';b.disabled=as.length>=s.cupo;
    b.onclick=()=>accion('/api/profesor/residencias/seleccionar',{
       method:'POST',body:JSON.stringify({id_alumno:a.id_alumno})},'Alumno añadido a la selección. Aún no se ha notificado.');
    card.appendChild(b);return card;
  });
}
async function actualizar(){
  try { estadoResidencias=await solicitar('/api/profesor/residencias'); representar(); }
  catch(e){aviso(e.message,true);}
}
async function accion(url,opciones,mensaje){
  try { await solicitar(url,opciones);aviso(mensaje);await actualizar(); }
  catch(e){aviso(e.message,true);}
}
document.addEventListener('DOMContentLoaded',()=>{
  nodo('buscarCandidato').addEventListener('input',representar);
  nodo('confirmarAsesorados').addEventListener('click',async()=>{
    if(!confirm('¿Confirmar tus alumnos seleccionados? Se les enviará una notificación en SPOTE.'))return;
    try{const r=await solicitar('/api/profesor/residencias/confirmar',{method:'POST',body:'{}'});
      aviso(`Se confirmaron ${r.confirmados} alumnos y se generaron sus notificaciones.`);await actualizar();
    }catch(e){aviso(e.message,true);}
  });
  actualizar();
});
